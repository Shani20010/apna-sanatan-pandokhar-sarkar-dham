import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { createClient } from "@supabase/supabase-js";
import { allRows, allMedia } from "../lib/queries.mjs";
const url = process.env.SUPABASE_URL,
  key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key)
  throw Error(
    "Set SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY in your local terminal only.",
  );
const target = path.resolve(
  process.argv[2] || `backups/${new Date().toISOString().replaceAll(":", "-")}`,
);
await fs.mkdir(target, { recursive: true });
if (await fs.stat(path.join(target, "content.json")).catch(() => null))
  throw Error("Choose a new empty backup directory.");
const db = createClient(url, key, {
  auth: { persistSession: false, autoRefreshToken: false },
});
const [drafts, published, audit] = await Promise.all([
  allRows(db, "content_drafts"),
  allRows(db, "content_public"),
  allRows(db, "content_audit"),
]);
await fs.mkdir(path.join(target, "media"), { recursive: true });
const files = [];
for (const f of await allMedia(db)) {
  if (!/^[a-zA-Z0-9_.-]+$/.test(f.name) || [".", ".."].includes(f.name))
    throw Error("Unexpected object name");
  const object = "uploads/" + f.name;
  const { data, error } = await db.storage.from("site-media").download(object);
  if (error) throw Error("Media download failed; backup incomplete");
  const bytes = Buffer.from(await data.arrayBuffer());
  await fs.writeFile(path.join(target, "media", f.name), bytes, {
    mode: 0o600,
  });
  files.push({
    path: object,
    type: data.type,
    sha256: createHash("sha256").update(bytes).digest("hex"),
  });
}
await fs.writeFile(
  path.join(target, "content.json"),
  JSON.stringify(
    {
      version: 1,
      exported_at: new Date().toISOString(),
      drafts,
      published,
      audit,
      files,
    },
    null,
    2,
  ),
  { mode: 0o600 },
);
console.log(
  `Backup complete: ${drafts.length} drafts, ${published.length} published, ${files.length} media files. Folder: ${target}`,
);
