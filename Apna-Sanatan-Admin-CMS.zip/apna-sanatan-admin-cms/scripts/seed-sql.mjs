import fs from "node:fs";
import { schemas } from "../lib/content-schema.mjs";
const rows = JSON.parse(fs.readFileSync("data/seed.json", "utf8"));
const quote = (v) => "'" + v.replaceAll("'", "''") + "'";
let sql =
  "-- Run AFTER 001_cms.sql, once. Existing edits are never overwritten.\nBEGIN;\n";
for (const r of rows) {
  const d = schemas[r.kind].parse(r.data);
  sql += `WITH inserted AS (INSERT INTO public.content_drafts(id,kind,data,sort_order) VALUES (${quote(r.id)},${quote(r.kind)},${quote(JSON.stringify(d))}::jsonb,${r.sort_order}) ON CONFLICT(id) DO NOTHING RETURNING *) INSERT INTO public.content_public(id,kind,data,sort_order,starts_at,ends_at,revision) SELECT id,kind,data,sort_order,starts_at,ends_at,revision FROM inserted;\n`;
}
sql += "COMMIT;\n";
fs.writeFileSync("supabase/seed.sql", sql);
console.log(`Validated ${rows.length} seed records.`);
