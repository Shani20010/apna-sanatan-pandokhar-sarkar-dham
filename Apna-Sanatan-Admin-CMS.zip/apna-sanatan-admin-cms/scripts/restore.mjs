import fs from "node:fs/promises";
import path from "node:path";
import { createHash } from "node:crypto";
import { createClient } from "@supabase/supabase-js";
import { schemas, recordSchema } from "../lib/content-schema.mjs";
if (!process.argv.includes("--confirm-empty-project"))
  throw Error(
    "Use only a newly migrated EMPTY project. Pass backup folder and --confirm-empty-project.",
  );
const source = process.argv[2];
if (!source || source.startsWith("--"))
  throw Error("Backup folder is required");
const root = path.resolve(source),
  backup = JSON.parse(
    await fs.readFile(path.join(root, "content.json"), "utf8"),
  );
if (backup.version !== 1 || !Array.isArray(backup.files))
  throw Error(
    "Full backup with media manifest required; admin JSON alone is not enough.",
  );
const url = process.env.SUPABASE_URL,
  key = process.env.SUPABASE_SERVICE_ROLE_KEY;
if (!url || !key) throw Error("Set local-only Supabase backup credentials.");
const db = createClient(url, key, {
  auth: { persistSession: false, autoRefreshToken: false },
});
for (const table of ["content_drafts", "content_public"]) {
  const { data, error } = await db.from(table).select("id").limit(1);
  if (error) throw Error("Migration must be applied first.");
  if (data.length) throw Error("Target is not empty. Refusing to overwrite.");
}
for (const r of [...backup.drafts, ...backup.published]) {
  schemas[r.kind]?.parse(r.data);
  recordSchema.parse({
    id: r.id,
    kind: r.kind,
    data: r.data,
    sort_order: r.sort_order,
    revision: r.revision,
    starts_at: r.starts_at,
    ends_at: r.ends_at,
  });
}
// Validate all media before the first remote write.
const media = [];
for (const f of backup.files) {
  if (!/^uploads\/[a-zA-Z0-9_-][a-zA-Z0-9_.-]*$/.test(f.path))
    throw Error("Unsafe media path");
  const bytes = await fs.readFile(
    path.join(root, "media", path.basename(f.path)),
  );
  if (createHash("sha256").update(bytes).digest("hex") !== f.sha256)
    throw Error("Media checksum failed");
  media.push({ f, bytes });
}
for (const { f, bytes } of media) {
  const { error } = await db.storage
    .from("site-media")
    .upload(f.path, bytes, { contentType: f.type, upsert: false });
  if (error)
    throw Error(
      "Storage upload failed. Keep backup; resolve target conflict before retry.",
    );
}
for (const [table, rows] of [
  ["content_drafts", backup.drafts],
  ["content_public", backup.published],
])
  for (let i = 0; i < rows.length; i += 100) {
    const { error } = await db.from(table).insert(rows.slice(i, i + 100));
    if (error)
      throw Error(
        "Restore interrupted. Recreate a clean target and retry; backup is unchanged.",
      );
  }
console.log(
  "Content/media restored. Auth users and admin membership must be recreated by the owner. Historical audit is retained in backup only.",
);
