# अपना सनातन पण्डोखर सरकार धाम — Independent CMS

A real Next.js App Router application with Supabase PostgreSQL, Auth and private Storage. The original supplied static website has been migrated to request-time content rendering. No ChatGPT API, login, subscription or Sites hosting is required after independent deployment.

**Start here:** [सरल Hindi setup guide](docs/HINDI-GUIDE.md).

## Included

- Mobile-friendly `/admin`: gallery, Facebook videos, hero media, banners, announcements, FAQs, website settings/SEO.
- Email/password login, logout and password reset, owner-controlled admin allowlist.
- Separate drafts and published snapshots; preview, visibility scheduling, order, manual verified views.
- Server authorization, Origin checks, schema validation, PostgreSQL RLS and private draft media.
- Original 12 gallery photos, 8 hero entries, original videos and five requested featured videos, Hindi descriptions and contacts.
- Browser-side image compression; click-to-load optional canonical Facebook embeds with direct-link fallback.
- SQL migration/seed, backup/restore tools, Netlify configuration and automated tests.

## Run

Node.js 22+:

```sh
npm ci
cp .env.example .env.local
# Fill the THREE public configuration values; never add a service-role key.
npm run dev
```

Without Supabase configuration the public website uses the bundled seed for preview and admin is blocked with setup instructions. This is **not** a functioning production CMS until owner setup is completed. When Supabase is configured, database errors fail visibly instead of exposing bundled unpublished content.

```sh
npm run seed:sql
npm test
npm run build
npm start
```

Deploy through GitHub → Netlify using `netlify.toml`. This is dynamic Next.js; **do not use static export or drag-and-drop an `out` folder**. Public database content changes require no rebuild; environment variables and code changes do.

## Owner setup still required

Create Supabase/Netlify/GitHub accounts, apply `supabase/migrations/001_cms.sql`, apply `supabase/seed.sql`, create Auth user and admin membership, configure email/redirect URLs, set environment variables and deploy. See the Hindi guide for exact steps and acceptance tests.

No production accounts or passwords were created. Current live ChatGPT site was not modified. Hosted login/reset, upload delivery, Netlify deployment and real-device checks require your configured accounts; see [test report](docs/TEST-REPORT.md).

## Structure

- `app/`: server-rendered pages, protected APIs and authentication callback.
- `components/`: original themed public UI and mobile CMS.
- `lib/`: Supabase clients, authorization, validation, pagination and media mapping.
- `supabase/`: schema, RLS policies, transactional publish RPCs and idempotent initial content seed.
- `public/images`, `public/media`: preserved original assets, independent of ChatGPT URLs.
- `legacy-source/`: old homepage and browser-local script for reference only; not loaded by the app.
- `scripts/`: seed generation, full content/media backup and empty-project restore.
- `tests/`: schema/content and PostgreSQL-engine security/lifecycle tests.

Keep the source ZIP and backups in your own safe storage. Media rights and existing devotional descriptions remain as supplied; no new medical, miracle or unverified numeric popularity claims are added.
