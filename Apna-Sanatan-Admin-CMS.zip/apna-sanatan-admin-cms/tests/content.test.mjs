import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import {
  schemas,
  safeUrl,
  safeMedia,
  facebookUrl,
  recordSchema,
} from "../lib/content-schema.mjs";
import { allRows, allMedia } from "../lib/queries.mjs";
const seed = JSON.parse(fs.readFileSync("data/seed.json", "utf8"));
test("every seed record validates; all referenced bundled media exists", () => {
  for (const r of seed) {
    schemas[r.kind].parse(r.data);
    recordSchema.parse(r);
    for (const k of ["media", "thumbnail", "about_image", "og_image"])
      if (r.data[k]?.startsWith("/"))
        assert.ok(fs.existsSync("public" + r.data[k]), r.data[k]);
  }
});
test("preserves 12 gallery photos, 8 hero slides and 7 unique Facebook links", () => {
  assert.equal(seed.filter((r) => r.kind === "photo").length, 12);
  assert.equal(seed.filter((r) => r.kind === "hero").length, 8);
  assert.equal(
    new Set(seed.filter((r) => r.kind === "video").map((r) => r.data.url)).size,
    7,
  );
});
test("blocks script URLs, credentials, lookalike Facebook hosts and traversal", () => {
  for (const u of [
    "javascript:alert(1)",
    "data:text/html,a",
    "http://facebook.com",
    "https://user:pw@facebook.com",
  ]) {
    assert.equal(safeUrl(u), false);
    assert.equal(facebookUrl(u), false);
  }
  assert.equal(facebookUrl("https://facebook.com.attacker.test/"), false);
  assert.equal(facebookUrl("https://www.facebook.com/share/v/abc/"), true);
  assert.equal(safeMedia("/images/../secret"), false);
  assert.equal(safeMedia("https://attacker.test/a.jpg"), false);
  assert.equal(safeMedia("uploads/a.webp"), true);
});
test("verified views require date and positive count", () => {
  const v = seed.find((r) => r.kind === "video").data;
  assert.equal(
    schemas.video.safeParse({ ...v, views_verified: true }).success,
    false,
  );
  assert.equal(
    schemas.video.safeParse({
      ...v,
      views_verified: true,
      views: 1000000,
      views_date: "2026-10-24",
    }).success,
    true,
  );
  assert.equal(schemas.video.safeParse({ ...v, views: -2 }).success, false);
  assert.equal(
    schemas.video.safeParse({
      ...v,
      views_verified: true,
      views: 10,
      views_date: "2026-99-99",
    }).success,
    false,
  );
});
test("dates reject invalid intervals and records reject extra fields", () => {
  const r = seed[0];
  assert.equal(
    recordSchema.safeParse({
      ...r,
      starts_at: "2026-10-25T00:00:00Z",
      ends_at: "2026-10-24T00:00:00Z",
    }).success,
    false,
  );
  assert.equal(recordSchema.safeParse({ ...r, admin: true }).success, false);
});
test("published fallback has no unverified view counts", () => {
  for (const r of seed.filter((r) => r.kind === "video"))
    assert.equal(r.data.views_verified, false);
});
test("pagination loads more than Supabase default cap", async () => {
  const rows = Array.from({ length: 1203 }, (_, id) => ({ id }));
  const db = {
    from: () => ({
      select: () => ({
        order: () => ({
          range: async (a, b) => ({ data: rows.slice(a, b + 1), error: null }),
        }),
      }),
    }),
  };
  assert.equal((await allRows(db, "any")).length, 1203);
  const storage = {
    storage: {
      from: () => ({
        list: async (_, { limit, offset }) => ({
          data: rows.slice(offset, offset + limit),
          error: null,
        }),
      }),
    },
  };
  assert.equal((await allMedia(storage)).length, 1203);
});
test("canonical embeds reject share links and deceptive domains", () => {
  const v = seed.find((r) => r.kind === "video").data;
  assert.equal(
    schemas.video.safeParse({
      ...v,
      embed_url: "https://www.facebook.com/example/videos/123456789/",
    }).success,
    true,
  );
  assert.equal(
    schemas.video.safeParse({ ...v, embed_url: v.url }).success,
    false,
  );
  assert.equal(
    schemas.video.safeParse({
      ...v,
      embed_url: "https://facebook.com.attacker.test/videos/12345",
    }).success,
    false,
  );
});
test("gallery Hindi details, categories, sources and paths match original JSON exactly", () => {
  const original = JSON.parse(fs.readFileSync("public/photos.json", "utf8"));
  for (const p of original) {
    const row = seed.find((r) => r.kind === "photo" && r.data.media === p.path);
    assert.ok(row);
    for (const k of ["title", "description", "note", "source", "category"])
      assert.equal(row.data[k], p[k]);
    assert.equal(row.data.thumbnail, p.thumb);
  }
});
