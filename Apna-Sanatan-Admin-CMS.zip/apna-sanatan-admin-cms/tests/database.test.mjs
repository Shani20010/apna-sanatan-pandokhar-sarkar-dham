import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import { PGlite } from "@electric-sql/pglite";
// Actual PostgreSQL engine. Only Supabase-owned auth/storage scaffolding is mocked.
test("PostgreSQL migrations, content lifecycle, roles and Storage RLS", async (t) => {
  const db = new PGlite();
  await db.exec(
    `create role anon;create role authenticated;create role service_role bypassrls;create schema auth;create schema storage;create table auth.users(id uuid primary key);create function auth.uid() returns uuid language sql stable as $$select nullif(current_setting('request.jwt.claim.sub',true),'')::uuid$$;grant usage on schema auth,storage to anon,authenticated;grant execute on function auth.uid() to anon,authenticated;create table storage.buckets(id text primary key,name text,public boolean,file_size_limit bigint,allowed_mime_types text[]);create table storage.objects(id uuid default gen_random_uuid(),bucket_id text,name text);alter table storage.objects enable row level security;grant select,insert,update,delete on storage.objects to anon,authenticated;`,
  );
  await db.exec(fs.readFileSync("supabase/migrations/001_cms.sql", "utf8"));
  await db.exec(fs.readFileSync("supabase/seed.sql", "utf8"));
  const owner = "11111111-1111-4111-8111-111111111111",
    visitor = "22222222-2222-4222-8222-222222222222";
  await db.query("insert into auth.users values ($1),($2)", [owner, visitor]);
  await db.query("insert into public.site_admins(user_id) values ($1)", [
    owner,
  ]);
  async function role(name, user = "") {
    await db.exec("reset role");
    await db.query("select set_config('request.jwt.claim.sub',$1,false)", [
      user,
    ]);
    await db.exec("set role " + name);
  }
  const count = async (table) =>
    (await db.query("select count(*)::int n from " + table)).rows[0].n;
  await t.test(
    "anonymous reads seeded published only, cannot read drafts or modify",
    async () => {
      await role("anon");
      assert.equal(await count("content_public"), 34);
      await assert.rejects(
        () => db.query("select * from content_drafts"),
        /permission denied/,
      );
      await assert.rejects(
        () =>
          db.query(
            "insert into content_public(id,kind,data,sort_order,revision) values(gen_random_uuid(),'photo','{}',0,1)",
          ),
        /permission denied/,
      );
    },
  );
  await t.test(
    "ordinary signed-in users cannot elevate or mutate",
    async () => {
      await role("authenticated", visitor);
      assert.equal((await db.query("select is_admin() x")).rows[0].x, false);
      assert.equal(await count("content_drafts"), 0);
      await assert.rejects(
        () =>
          db.query("insert into site_admins(user_id) values($1)", [visitor]),
        /permission denied/,
      );
      await assert.rejects(
        () =>
          db.query(
            "select save_content(null,'announcement','{}',0,null,null,0)",
          ),
        /insufficient_privilege/,
      );
      await assert.rejects(
        () =>
          db.query(
            "insert into content_drafts(kind,data) values('announcement','{}')",
          ),
        /row-level security/,
      );
    },
  );
  let id;
  await t.test("admin saves draft; draft absent from public", async () => {
    await role("authenticated", owner);
    const r = await db.query(
      "select * from save_content(null,'announcement',$1,90,null,null,0)",
      [{ title: "First", media: "uploads/test.webp" }],
    );
    id = r.rows[0].id;
    assert.ok(id);
    await db.query(
      "insert into storage.objects(bucket_id,name) values('site-media','uploads/test.webp'),('site-media','uploads/unused.webp')",
    );
    await role("anon");
    assert.equal(
      (await db.query("select * from content_public where id=$1", [id])).rows
        .length,
      0,
    );
    assert.equal(await count("storage.objects"), 0);
  });
  await t.test(
    "publish makes record and media readable; draft edit stays private",
    async () => {
      await role("authenticated", owner);
      await db.query("select publish_content($1,1)", [id]);
      await db.query(
        "select save_content($1,'announcement',$2,90,null,null,1)",
        [id, { title: "Changed draft", media: "uploads/test.webp" }],
      );
      await role("anon");
      assert.equal(
        (await db.query("select data from content_public where id=$1", [id]))
          .rows[0].data.title,
        "First",
      );
      assert.equal(await count("storage.objects"), 1);
    },
  );
  await t.test("stale revisions fail rather than overwrite", async () => {
    await role("authenticated", owner);
    await assert.rejects(
      () => db.query("select publish_content($1,1)", [id]),
      /Content changed/,
    );
    await assert.rejects(
      () =>
        db.query("select save_content($1,'announcement','{}',0,null,null,1)", [
          id,
        ]),
      /Content changed/,
    );
    await db.query("select publish_content($1,2)", [id]);
  });
  await t.test(
    "in-use storage cannot be deleted and no overwrite policy exists",
    async () => {
      await role("authenticated", owner);
      assert.equal(
        (
          await db.query(
            "delete from storage.objects where name='uploads/test.webp' returning *",
          )
        ).rows.length,
        0,
      );
      assert.equal(
        (
          await db.query(
            "update storage.objects set name='uploads/overwrite.webp' returning *",
          )
        ).rows.length,
        0,
      );
      assert.equal(
        (
          await db.query(
            "delete from storage.objects where name='uploads/unused.webp' returning *",
          )
        ).rows.length,
        1,
      );
    },
  );
  await t.test(
    "schedule hides future records and media from visitors",
    async () => {
      await role("authenticated", owner);
      await db.query(
        "select save_content($1,'announcement',$2,90,now()+interval '1 day',null,2)",
        [id, { title: "Future", media: "uploads/test.webp" }],
      );
      await db.query("select publish_content($1,3)", [id]);
      await role("anon");
      assert.equal(
        (await db.query("select * from content_public where id=$1", [id])).rows
          .length,
        0,
      );
      assert.equal(await count("storage.objects"), 0);
    },
  );
  await t.test("unpublish, seed rerun, deletion and audit", async () => {
    await role("authenticated", owner);
    await db.query("select remove_content($1,3,false)", [id]);
    await role("postgres");
    await db.exec(fs.readFileSync("supabase/seed.sql", "utf8"));
    assert.equal(
      (await db.query("select * from content_public where id=$1", [id])).rows
        .length,
      0,
    );
    await role("authenticated", owner);
    await db.query("select remove_content($1,3,true)", [id]);
    assert.equal(
      (await db.query("select * from content_drafts where id=$1", [id])).rows
        .length,
      0,
    );
    assert.equal(
      (
        await db.query(
          "delete from storage.objects where name='uploads/test.webp' returning *",
        )
      ).rows.length,
      1,
    );
    assert.ok((await count("content_audit")) > 68);
  });
  await db.close();
});
