import { mediaUrl, viewLabel } from "../lib/media.mjs";
import { settingsFrom } from "../lib/content";
import { Gallery, Hero, NavMenu, FacebookEmbed } from "./public-interactive";
const Facebook = ({
  url,
  children = "Facebook पर देखें ↗",
  className = "pill",
}) => (
  <a className={className} href={url} target="_blank" rel="noopener noreferrer">
    {children}
  </a>
);
function VideoCard({ item }) {
  const v = item.data;
  return (
    <article className="popular-card">
      <a
        className="popular-thumb"
        href={v.url}
        target="_blank"
        rel="noopener noreferrer"
        aria-label={v.title + " — Facebook पर देखें"}
      >
        {v.thumbnail && (
          <img src={mediaUrl(v.thumbnail)} alt={v.title} loading="lazy" />
        )}
        {v.views_verified && v.views > 0 && (
          <span className="popular-views">★ {viewLabel(v.views)}</span>
        )}
        <span className="popular-play" aria-hidden="true">
          ▶
        </span>
      </a>
      <div className="popular-info">
        {v.trending && (
          <span className="popular-label">TRENDING • लोकप्रिय</span>
        )}
        <h3>{v.title}</h3>
        {v.description && <p>{v.description}</p>}
        {v.title_en && <small lang="en">{v.title_en}</small>}
        {v.description_en && <p lang="en">{v.description_en}</p>}
        <Facebook url={v.url} />
        {v.embed_url && <FacebookEmbed url={v.embed_url} />}
        {v.views_verified && v.views_date && (
          <p className="popular-note">
            Views जाँचे गए: {v.views_date} · संख्या बदल सकती है।
          </p>
        )}
      </div>
    </article>
  );
}
export default function Website({ rows, mode = "home", preview = false }) {
  const s = settingsFrom(rows),
    get = (k) => rows.filter((r) => r.kind === k),
    videos = get("video"),
    featured = videos.filter((r) => r.data.featured),
    photos = get("photo"),
    banners = get("banner");
  return (
    <>
      {preview && (
        <div className="preview-strip">
          DRAFT PREVIEW — ये बदलाव अभी public नहीं हैं।{" "}
          <a href="/admin">Admin वापस जाएँ</a>
        </div>
      )}
      <header id="top">
        <a className="brand" href="/">
          <span className="brand-icon">ॐ</span>
          <span>
            <small>{s.brand_small}</small>
            <b>{s.brand_main}</b>
          </span>
        </a>
        <form className="search" action="/gallery">
          <label className="sr-only" htmlFor="site-search">
            दर्शन खोजें
          </label>
          <input
            id="site-search"
            name="q"
            placeholder="दर्शन, श्रृंगार या तस्वीर खोजें…"
          />
          <button aria-label="खोजें">⌕</button>
        </form>
        <Facebook className="social-pill" url={s.facebook_url}>
          Facebook ↗
        </Facebook>
        <NavMenu />
      </header>
      <nav id="nav">
        <a href="/#top">⌂ मुख्य पेज</a>
        <a href="/#collection">▧ दर्शन गैलरी</a>
        <a href="/#popular">★ लोकप्रिय वीडियो</a>
        <a href="/#videos">Facebook वीडियो</a>
        <a href="/#about">गुरु परंपरा</a>
        <a href="/#contact">☎ संपर्क</a>
      </nav>
      {get("announcement").map((r) => (
        <aside className="announcement" key={r.id}>
          <strong className="tag">{r.data.title}</strong>
          <span>{r.data.description}</span>
          {r.data.description_en && (
            <span lang="en">{r.data.description_en}</span>
          )}
          {r.data.button_url && (
            <a href={r.data.button_url}>{r.data.button_text || "देखें →"}</a>
          )}
        </aside>
      ))}
      <main>
        {mode !== "home" && (
          <div className="gallery-hero">
            <span className="eyebrow">अपना सनातन</span>
            <h1>{mode === "gallery" ? s.gallery_heading : s.video_heading}</h1>
            <a href="/">← मुख्य पेज</a>
          </div>
        )}
        {mode === "home" && <Hero items={get("hero")} settings={s} />}
        {mode === "home" && featured.length > 0 && (
          <section className="section popular-section" id="popular">
            <div className="section-heading">
              <div>
                <span className="eyebrow">लोकप्रिय चयन · अपना सनातन</span>
                <h2>{s.popular_heading}</h2>
                <p>हमारे चुनिंदा Facebook videos — एक साथ, आपके लिए।</p>
              </div>
              <a className="pill" href="#videos">
                और वीडियो देखें ↓
              </a>
            </div>
            <div className="popular-grid">
              {featured.map((v) => (
                <VideoCard key={v.id} item={v} />
              ))}
            </div>
          </section>
        )}
        {mode !== "videos" && (
          <section className="section collection-section" id="collection">
            <div className="section-heading centered">
              <span className="eyebrow">अपनी आस्था से जुड़ें</span>
              <h2>{s.gallery_heading}</h2>
              <p>{s.gallery_description}</p>
            </div>
            <Gallery photos={photos} expanded={mode === "gallery"} />
          </section>
        )}
        {mode === "home" && (
          <>
            <section id="about" className="section about-cms">
              <span className="eyebrow">सनातन संस्कृति</span>
              <h2>{s.about_heading}</h2>
              <p>{s.about_text}</p>
              {s.about_image && (
                <img
                  src={mediaUrl(s.about_image)}
                  alt={s.about_heading}
                  loading="lazy"
                />
              )}
            </section>
            {banners.map((r) => (
              <section className="devotion-banner" key={r.id}>
                <div>
                  <span className="eyebrow">अपनी आस्था से जुड़ें</span>
                  <h2>{r.data.title}</h2>
                  <p>{r.data.description}</p>
                  {r.data.description_en && (
                    <p lang="en">{r.data.description_en}</p>
                  )}
                  {r.data.button_url && (
                    <a className="pill" href={r.data.button_url}>
                      {r.data.button_text || "देखें →"}
                    </a>
                  )}
                </div>
                <img
                  src={mediaUrl(r.data.media)}
                  alt={r.data.title}
                  loading="lazy"
                />
              </section>
            ))}
            <section className="section">
              <div className="section-heading">
                <h2>अपनी आस्था का रंग चुनें</h2>
              </div>
              <div className="category-grid">
                {[
                  ...new Set(
                    photos.map((p) => p.data.category).filter(Boolean),
                  ),
                ].map((c) => {
                  const p = photos.find((p) => p.data.category === c);
                  return (
                    <a
                      key={c}
                      href={"/gallery?category=" + encodeURIComponent(c)}
                    >
                      <img
                        src={mediaUrl(p.data.thumbnail || p.data.media)}
                        alt={c}
                        loading="lazy"
                      />
                      <div>
                        <small>दर्शन संग्रह</small>
                        <h3>{c}</h3>
                        <span>तस्वीरें देखें ↗</span>
                      </div>
                    </a>
                  );
                })}
              </div>
            </section>
          </>
        )}
        {mode !== "gallery" && (
          <section id="videos" className="section">
            <div className="section-heading">
              <div>
                <span className="eyebrow">भक्ति के स्वर</span>
                <h2>{s.video_heading}</h2>
                <p>{s.video_description}</p>
              </div>
            </div>
            <div className="video-banner">
              <div>
                <span>हमारा Facebook परिवार</span>
                <h3>एक भजन। कुछ पल सुकून के।</h3>
                <p>हमारे पेज पर आएँ और भक्ति की इस यात्रा से जुड़ें।</p>
              </div>
              <Facebook className="pill light" url={s.facebook_url}>
                Facebook पेज ↗
              </Facebook>
            </div>
            <div className="popular-grid video-collection">
              {videos.map((v) => (
                <VideoCard key={v.id} item={v} />
              ))}
            </div>
          </section>
        )}
        {mode === "home" && (
          <section className="faq section">
            <div>
              <span className="eyebrow">आपके सवाल</span>
              <h2>
                जानें, समझें,
                <br />
                <em>और जुड़ें।</em>
              </h2>
              <p>दर्शन और वेबसाइट से जुड़ी छोटी-छोटी बातें।</p>
            </div>
            <div className="faq-list">
              {get("faq").map((r) => (
                <details key={r.id}>
                  <summary>{r.data.title}</summary>
                  <p>{r.data.description}</p>
                  {r.data.description_en && (
                    <p lang="en">{r.data.description_en}</p>
                  )}
                </details>
              ))}
            </div>
          </section>
        )}
      </main>
      <footer id="contact">
        <div className="footer-top">
          <h2>{s.footer_text}</h2>
          <Facebook className="pill light" url={s.facebook_url}>
            हमारा Facebook परिवार ↗
          </Facebook>
        </div>
        <div className="footer-grid">
          <div className="footer-brand">
            <small>{s.brand_small}</small>
            <strong>{s.brand_main}</strong>
            <p>दर्शन, स्मरण और सनातन संस्कृति का अपना संसार।</p>
          </div>
          <div>
            <h3>दर्शन करें</h3>
            <a href="/#collection">फोटो और विवरण</a>
            <a href="/#videos">Facebook वीडियो</a>
          </div>
          <div>
            <h3>संपर्क करें</h3>
            <a href={"tel:" + s.contact_phone}>{s.contact_phone}</a>
            <a href={"mailto:" + s.contact_email}>{s.contact_email}</a>
            <Facebook url={s.facebook_url} className="">
              Facebook पेज ↗
            </Facebook>
          </div>
          <div>
            <h3>संदर्भ</h3>
            <a
              href="https://shripandokharsarkardham.com/"
              target="_blank"
              rel="noopener noreferrer"
            >
              श्री पंडोखर सरकार धाम ↗
            </a>
            <p>दृश्य विवरण और उपलब्ध संदर्भ प्रत्येक फोटो के साथ दिए गए हैं।</p>
          </div>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} {s.brand_small} {s.brand_main}
          </span>
          <span>{s.footer_note}</span>
          <a href="/admin">Admin</a>
        </div>
      </footer>
      <a
        className="floating-call"
        href={"tel:" + s.contact_phone}
        aria-label="फोन करें"
      >
        ☎
      </a>
    </>
  );
}
