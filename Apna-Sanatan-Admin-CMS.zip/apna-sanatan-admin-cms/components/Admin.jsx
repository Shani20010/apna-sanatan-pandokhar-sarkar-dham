"use client";
import { useEffect, useState } from "react";
import {
  kinds,
  labels,
  fields,
  fieldLabels,
  emptyData,
} from "../lib/content-schema.mjs";
import { browserClient } from "../lib/supabase-browser";
import { uploadMedia } from "../lib/upload";
import { mediaUrl } from "../lib/media.mjs";
const mediaFields = ["media", "thumbnail", "about_image", "og_image"];
const boolFields = ["featured", "trending", "views_verified"];
const localDate = (value) =>
  value
    ? new Date(
        new Date(value).getTime() - new Date(value).getTimezoneOffset() * 60000,
      )
        .toISOString()
        .slice(0, 16)
    : "";
async function request(path, body, method = "POST") {
  const res = await fetch(path, {
    method,
    headers: { "Content-Type": "application/json" },
    ...(body ? { body: JSON.stringify(body) } : {}),
    cache: "no-store",
  });
  const json = await res.json();
  if (!res.ok) throw Error(json.error || "Request failed");
  return json;
}
export default function Admin({ email }) {
  const [state, setState] = useState({ drafts: [], published: [], audit: [] }),
    [tab, setTab] = useState("overview"),
    [edit, setEdit] = useState(null),
    [dirty, setDirty] = useState(false),
    [busy, setBusy] = useState(false),
    [message, setMessage] = useState(""),
    [files, setFiles] = useState([]);
  const published = new Map(state.published.map((r) => [r.id, r]));
  async function refresh() {
    setState(await request("/api/admin/content", null, "GET"));
  }
  useEffect(() => {
    refresh().catch((e) => setMessage(e.message));
  }, []);
  useEffect(() => {
    const listener = (e) => {
      if (dirty) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", listener);
    return () => window.removeEventListener("beforeunload", listener);
  }, [dirty]);
  async function task(fn) {
    setBusy(true);
    setMessage("");
    try {
      await fn();
    } catch (e) {
      setMessage(e.message);
    } finally {
      setBusy(false);
    }
  }
  function choose(next) {
    if (dirty && !confirm("बिना save किए बदलाव छोड़ें?")) return;
    setEdit(next);
    setDirty(false);
  }
  function change(key, value) {
    setEdit((r) => ({
      ...r,
      data: {
        ...r.data,
        ...(key === "media" && r.kind === "photo" ? { thumbnail: "" } : {}),
        [key]: value,
      },
    }));
    setDirty(true);
  }
  async function save() {
    const result = await request("/api/admin/content", {
      action: "save",
      record: edit,
    });
    setEdit(recordForForm(result.record));
    setDirty(false);
    await refresh();
    setMessage("Draft सुरक्षित है। Preview देखें, फिर Publish करें।");
  }
  function recordForForm(r) {
    return {
      id: r.id,
      kind: r.kind,
      data: r.data,
      sort_order: r.sort_order,
      revision: r.revision,
      starts_at: r.starts_at,
      ends_at: r.ends_at,
    };
  }
  async function action(type, r) {
    if (
      ["delete", "unpublish"].includes(type) &&
      !confirm(
        type === "delete"
          ? "यह content हमेशा के लिए हटाएँ? Media file अपने-आप नहीं हटेगी।"
          : "इस content को public website से छिपाएँ?",
      )
    )
      return;
    await request("/api/admin/content", {
      action: type,
      id: r.id,
      revision: r.revision,
    });
    await refresh();
    if (type === "delete") choose(null);
    setMessage(
      type === "publish"
        ? "Published! अब website refresh करने पर बदलाव दिखेगा।"
        : type === "unpublish"
          ? "Content अब public नहीं है।"
          : "Content हटा दिया गया।",
    );
  }
  async function listMedia() {
    const result = await request("/api/admin/media", null, "GET");
    setFiles(result.files);
  }
  return (
    <div className="admin-shell">
      <div className="admin-top">
        <a href="/" target="_blank" rel="noopener noreferrer">
          ॐ अपना सनातन · Website ↗
        </a>
        <span>{email}</span>
        <button
          disabled={busy}
          onClick={() =>
            task(async () => {
              const { error } = await browserClient().auth.signOut();
              if (error) throw error;
              location.assign("/login");
            })
          }
        >
          Logout
        </button>
      </div>
      <div className="admin-layout">
        <aside className="admin-nav">
          <h1>व्यवस्थापन</h1>
          {[
            ["overview", "Overview"],
            ...kinds.map((k) => [k, labels[k]]),
            ["media", "Media Library"],
            ["backup", "Backup"],
          ].map(([key, label]) => (
            <button
              aria-current={tab === key ? "page" : undefined}
              key={key}
              onClick={() => {
                if (dirty && !confirm("बिना save किए बदलाव छोड़ें?")) return;
                setTab(key);
                setEdit(null);
                setDirty(false);
                if (key === "media") task(listMedia);
              }}
            >
              {label}
            </button>
          ))}
        </aside>
        <main className="admin-main">
          <div role="status" className="admin-status">
            {busy ? "काम चल रहा है…" : message}
          </div>
          {tab === "overview" && (
            <>
              <h2>आपकी वेबसाइट, आपके हाथ में</h2>
              <p>
                Draft में बदलाव करें → Preview देखें → Publish दबाएँ। पुराने
                published content पर draft का असर नहीं होता।
              </p>
              <div className="admin-stats">
                {["photo", "video", "banner", "announcement"].map((k) => (
                  <button key={k} onClick={() => setTab(k)}>
                    <strong>
                      {
                        state.drafts.filter(
                          (r) => r.kind === k && published.has(r.id),
                        ).length
                      }
                    </strong>
                    {labels[k]}
                    <small>
                      {state.drafts.filter((r) => r.kind === k).length} कुल
                      drafts
                    </small>
                  </button>
                ))}
              </div>
              <div className="admin-actions">
                <button
                  onClick={() => {
                    setTab("photo");
                    choose({
                      kind: "photo",
                      data: emptyData("photo"),
                      sort_order: state.drafts.length * 10,
                      revision: 0,
                      starts_at: null,
                      ends_at: null,
                    });
                  }}
                >
                  + नई फोटो
                </button>
                <button
                  onClick={() => {
                    setTab("video");
                    choose({
                      kind: "video",
                      data: emptyData("video"),
                      sort_order: state.drafts.length * 10,
                      revision: 0,
                      starts_at: null,
                      ends_at: null,
                    });
                  }}
                >
                  + Facebook वीडियो
                </button>
                <a
                  className="admin-button"
                  href="/admin/preview"
                  target="_blank"
                >
                  Draft Preview ↗
                </a>
              </div>
              <h3>हाल ही में बदला गया</h3>
              {[...state.drafts]
                .sort((a, b) => b.updated_at.localeCompare(a.updated_at))
                .slice(0, 8)
                .map((r) => (
                  <button
                    className="admin-recent"
                    key={r.id}
                    onClick={() => {
                      setTab(r.kind);
                      choose(recordForForm(r));
                    }}
                  >
                    {r.data.title}
                    <small>
                      {new Date(r.updated_at).toLocaleString("hi-IN")}
                    </small>
                  </button>
                ))}
            </>
          )}
          {kinds.includes(tab) && (
            <>
              <div className="admin-heading">
                <h2>{labels[tab]}</h2>
                {tab !== "page" && (
                  <button
                    disabled={busy}
                    onClick={() =>
                      choose({
                        kind: tab,
                        data: emptyData(tab),
                        sort_order:
                          state.drafts
                            .filter((r) => r.kind === tab)
                            .reduce((m, r) => Math.max(m, r.sort_order), 0) +
                          10,
                        revision: 0,
                        starts_at: null,
                        ends_at: null,
                      })
                    }
                  >
                    + नया जोड़ें
                  </button>
                )}
              </div>
              {!edit ? (
                <div className="admin-list">
                  {state.drafts
                    .filter((r) => r.kind === tab)
                    .map((r) => (
                      <article key={r.id}>
                        {(r.data.thumbnail ||
                          r.data.media ||
                          r.data.about_image) && (
                          <img
                            src={mediaUrl(
                              r.data.thumbnail ||
                                r.data.media ||
                                r.data.about_image,
                            )}
                            alt=""
                            loading="lazy"
                          />
                        )}
                        <div>
                          <h3>{r.data.title}</h3>
                          <p>
                            {!published.has(r.id)
                              ? "Draft · छिपा हुआ"
                              : published.get(r.id).revision === r.revision
                                ? "Published"
                                : "Published · नए बदलाव draft में"}{" "}
                            · क्रम {r.sort_order}
                          </p>
                          {r.starts_at && (
                            <small>
                              आरंभ{" "}
                              {new Date(r.starts_at).toLocaleString("hi-IN")}
                            </small>
                          )}
                          {r.ends_at && (
                            <small>
                              समाप्ति{" "}
                              {new Date(r.ends_at).toLocaleString("hi-IN")}
                            </small>
                          )}
                        </div>
                        <button onClick={() => choose(recordForForm(r))}>
                          Edit / बदलें
                        </button>
                      </article>
                    ))}
                  {!state.drafts.some((r) => r.kind === tab) && (
                    <p>अभी कोई content नहीं है। “नया जोड़ें” दबाएँ।</p>
                  )}
                </div>
              ) : (
                <form
                  className="admin-form"
                  onSubmit={(e) => {
                    e.preventDefault();
                    task(save);
                  }}
                >
                  <fieldset disabled={busy}>
                    <button type="button" onClick={() => choose(null)}>
                      ← सूची में वापस
                    </button>
                    <h3>{edit.id ? "Content बदलें" : "नया Content"}</h3>
                    {fields[edit.kind].map((key) => (
                      <label
                        className={
                          boolFields.includes(key) ? "check-field" : ""
                        }
                        key={key}
                      >
                        {fieldLabels[key] || key}
                        {boolFields.includes(key) ? (
                          <input
                            type="checkbox"
                            checked={!!edit.data[key]}
                            onChange={(e) => change(key, e.target.checked)}
                          />
                        ) : key === "media_type" ? (
                          <select
                            value={edit.data[key]}
                            onChange={(e) => change(key, e.target.value)}
                          >
                            <option value="image">तस्वीर</option>
                            <option value="video">MP4 वीडियो</option>
                          </select>
                        ) : mediaFields.includes(key) ? (
                          <>
                            <input
                              value={edit.data[key]}
                              onChange={(e) => change(key, e.target.value)}
                              placeholder="Upload करें या मौजूदा media path चुनें"
                            />
                            <input
                              type="file"
                              accept={
                                key === "media" && edit.kind === "hero"
                                  ? "image/jpeg,image/png,image/webp,video/mp4"
                                  : "image/jpeg,image/png,image/webp"
                              }
                              disabled={busy}
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file)
                                  task(async () => {
                                    change(key, await uploadMedia(file));
                                    setMessage(
                                      "Upload हो गया। Draft save करना न भूलें।",
                                    );
                                  });
                                e.target.value = "";
                              }}
                            />
                            {edit.data[key] &&
                              !edit.data[key].endsWith(".mp4") && (
                                <img
                                  className="admin-media-preview"
                                  src={mediaUrl(edit.data[key])}
                                  alt="Upload preview"
                                />
                              )}
                            <small>
                              Photo अपने-आप compress होती है। अधिकतम 25 MB;
                              JPG/PNG/WebP या hero के लिए MP4।
                            </small>
                          </>
                        ) : key.includes("description") ||
                          key.includes("text") ||
                          key === "about_text" ||
                          key === "note" ? (
                          <textarea
                            rows={4}
                            value={edit.data[key]}
                            onChange={(e) => change(key, e.target.value)}
                          />
                        ) : (
                          <input
                            type={
                              key === "views"
                                ? "number"
                                : key === "views_date"
                                  ? "date"
                                  : "text"
                            }
                            min={key === "views" ? 0 : undefined}
                            value={edit.data[key]}
                            onChange={(e) =>
                              change(
                                key,
                                key === "views"
                                  ? Number(e.target.value)
                                  : e.target.value,
                              )
                            }
                          />
                        )}
                      </label>
                    ))}
                    <label>
                      दिखाने का क्रम (छोटी संख्या पहले)
                      <input
                        type="number"
                        min="0"
                        max="1000000"
                        value={edit.sort_order}
                        onChange={(e) => {
                          setEdit({
                            ...edit,
                            sort_order: Number(e.target.value),
                          });
                          setDirty(true);
                        }}
                      />
                    </label>
                    {edit.kind !== "page" && (
                      <div className="admin-two">
                        {[
                          ["starts_at", "कब से दिखाएँ (खाली = तुरंत)"],
                          ["ends_at", "कब तक दिखाएँ (खाली = हमेशा)"],
                        ].map(([key, label]) => (
                          <label key={key}>
                            {label}
                            <input
                              type="datetime-local"
                              value={localDate(edit[key])}
                              onChange={(e) => {
                                setEdit({
                                  ...edit,
                                  [key]: e.target.value
                                    ? new Date(e.target.value).toISOString()
                                    : null,
                                });
                                setDirty(true);
                              }}
                            />
                            <small>आपके फोन का स्थानीय समय</small>
                          </label>
                        ))}
                      </div>
                    )}
                    <div className="admin-publish">
                      <button disabled={busy} type="submit">
                        1. Draft Save
                      </button>
                      <a
                        className="admin-button"
                        href="/admin/preview"
                        target="_blank"
                      >
                        2. Preview ↗
                      </a>
                      <button
                        type="button"
                        disabled={busy || dirty || !edit.id}
                        onClick={() => task(() => action("publish", edit))}
                      >
                        3. Publish
                      </button>
                      {edit.kind !== "page" && edit.id && (
                        <>
                          <button
                            type="button"
                            disabled={busy || dirty}
                            onClick={() =>
                              task(() => action("unpublish", edit))
                            }
                          >
                            छिपाएँ / Unpublish
                          </button>
                          <button
                            type="button"
                            className="danger"
                            disabled={busy || dirty}
                            onClick={() => task(() => action("delete", edit))}
                          >
                            Delete
                          </button>
                        </>
                      )}
                    </div>
                    {dirty && (
                      <p>
                        Unsaved changes: पहले Draft Save करें। Preview में केवल
                        saved drafts दिखते हैं।
                      </p>
                    )}
                  </fieldset>
                </form>
              )}
            </>
          )}
          {tab === "media" && (
            <>
              <h2>Media Library</h2>
              <p>
                यहाँ केवल नए uploaded files हैं। पुराने bundled photos source
                ZIP में सुरक्षित हैं। इस्तेमाल हो रही file हटाई नहीं जा सकती।
                Path copy करके किसी दूसरे banner/photo में इस्तेमाल कर सकते हैं।
              </p>
              <button disabled={busy} onClick={() => task(listMedia)}>
                Refresh
              </button>
              <div className="admin-list">
                {files.map((f) => (
                  <article key={f.name}>
                    {!f.name.endsWith(".mp4") && (
                      <img
                        alt=""
                        src={mediaUrl("uploads/" + f.name)}
                        loading="lazy"
                      />
                    )}
                    <code>uploads/{f.name}</code>
                    <button
                      onClick={() =>
                        task(async () => {
                          await navigator.clipboard.writeText(
                            "uploads/" + f.name,
                          );
                          setMessage("Path copy हो गया।");
                        })
                      }
                    >
                      Copy path
                    </button>
                    <button
                      disabled={busy}
                      onClick={() => {
                        if (confirm("Unused file हमेशा के लिए हटाएँ?"))
                          task(async () => {
                            await request(
                              "/api/admin/media",
                              { path: "uploads/" + f.name },
                              "DELETE",
                            );
                            await listMedia();
                            setMessage("File हट गई।");
                          });
                      }}
                    >
                      Delete
                    </button>
                  </article>
                ))}
              </div>
            </>
          )}
          {tab === "backup" && (
            <>
              <h2>Backup & सुरक्षा</h2>
              <p>
                Content JSON में drafts और published records आते हैं। Media का
                अलग backup जरूरी है। पूरी प्रक्रिया docs/HINDI-GUIDE.md में है।
              </p>
              <a className="admin-button" href="/api/admin/export">
                Content JSON डाउनलोड करें
              </a>
              <p>
                Source ZIP, database backup और Storage media को अपने सुरक्षित
                folder में रखें। Password या service-role key website पर upload
                न करें।
              </p>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
