"use client";
import { useEffect, useRef, useState } from "react";
import { mediaUrl } from "../lib/media.mjs";
export function NavMenu() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    document.getElementById("nav")?.classList.toggle("open", open);
  }, [open]);
  return (
    <button
      className="menu-toggle"
      aria-controls="nav"
      aria-expanded={open}
      onClick={() => setOpen(!open)}
    >
      ☰ <span className="sr-only">Menu</span>
    </button>
  );
}
export function Hero({ items, settings: s }) {
  const [index, setIndex] = useState(0),
    [paused, setPaused] = useState(false);
  const video = useRef(null);
  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) setPaused(true);
  }, []);
  useEffect(() => {
    if (paused || items.length < 2) return;
    const timer = setInterval(() => {
      if (!document.hidden) setIndex((i) => (i + 1) % items.length);
    }, 7000);
    return () => clearInterval(timer);
  }, [paused, items.length]);
  useEffect(() => {
    if (video.current) {
      if (paused) video.current.pause();
      else video.current.play().catch(() => {});
    }
  }, [paused, index]);
  const r = items[index % Math.max(items.length, 1)]?.data;
  return (
    <section className="hero" aria-label="धाम दर्शन">
      <div className="hero-background">
        {r?.media_type === "video" ? (
          <video
            ref={video}
            key={r.media}
            src={mediaUrl(r.media)}
            poster={mediaUrl(r.thumbnail) || undefined}
            muted
            autoPlay
            playsInline
            loop
            preload="metadata"
          />
        ) : (
          r && (
            <img
              key={r.media}
              src={mediaUrl(r.media)}
              alt={r.title}
              fetchPriority="high"
            />
          )
        )}
      </div>
      <div className="hero-shade" />
      <div className="hero-content">
        <span className="eyebrow">{s.hero_tagline}</span>
        <h1>{s.hero_heading}</h1>
        <p>{s.hero_description}</p>
        <a className="pill light" href="#collection">
          दर्शन गैलरी देखें ↗
        </a>
      </div>
      <div className="hero-controls">
        <button
          onClick={() => setIndex((i) => (i - 1 + items.length) % items.length)}
          disabled={!items.length}
          aria-label="पिछला दृश्य"
        >
          ‹
        </button>
        <button onClick={() => setPaused(!paused)}>
          {paused ? "▶ चलाएँ" : "Ⅱ रोकें"}
        </button>
        <button
          onClick={() => setIndex((i) => (i + 1) % items.length)}
          disabled={!items.length}
          aria-label="अगला दृश्य"
        >
          ›
        </button>
        <small>
          {items.length ? (index % items.length) + 1 : 0} / {items.length}
        </small>
      </div>
    </section>
  );
}
export function Gallery({ photos, expanded }) {
  const [category, setCategory] = useState("सभी"),
    [query, setQuery] = useState(""),
    [selected, setSelected] = useState(null);
  const modal = useRef(null);
  useEffect(() => {
    const p = new URLSearchParams(location.search);
    setQuery(p.get("q") || "");
    setCategory(p.get("category") || "सभी");
  }, []);
  const filtered = photos.filter(
    (r) =>
      (category === "सभी" || r.data.category === category) &&
      [r.data.title, r.data.description, r.data.title_en]
        .join(" ")
        .toLowerCase()
        .includes(query.toLowerCase()),
  );
  function show(r) {
    setSelected(r);
    modal.current.showModal();
  }
  return (
    <>
      <details className="gallery-accordion" open={expanded || undefined}>
        <summary>दर्शन गैलरी खोलें · {photos.length} तस्वीरें</summary>
        <div className="gallery-tools">
          <label>
            तस्वीर खोजें
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="शीर्षक या विवरण"
            />
          </label>
          <label>
            श्रेणी
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
            >
              {[
                "सभी",
                ...new Set(photos.map((r) => r.data.category).filter(Boolean)),
              ].map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </label>
        </div>
        <div className="gallery-grid">
          {filtered.map((r) => (
            <article className="gallery-card" key={r.id}>
              <button
                className="gallery-image"
                onClick={() => show(r)}
                aria-label={r.data.title + " — बड़ी तस्वीर"}
              >
                <img
                  src={mediaUrl(r.data.thumbnail || r.data.media)}
                  alt={r.data.title}
                  loading="lazy"
                  decoding="async"
                />
              </button>
              <div className="gallery-caption">
                <small>{r.data.category}</small>
                <h3>{r.data.title}</h3>
                <p>{r.data.description}</p>
                {r.data.title_en && <h4 lang="en">{r.data.title_en}</h4>}
                {r.data.description_en && (
                  <p lang="en">{r.data.description_en}</p>
                )}
                {r.data.note && <p className="photo-note">{r.data.note}</p>}
                {r.data.source && (
                  <a
                    href={r.data.source}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    संदर्भ ↗
                  </a>
                )}
              </div>
            </article>
          ))}
        </div>
        {!filtered.length && <p>इस खोज में तस्वीर नहीं मिली।</p>}
      </details>
      <dialog className="photo-dialog" ref={modal}>
        <button
          autoFocus
          className="dialog-close"
          onClick={() => modal.current.close()}
          aria-label="तस्वीर बंद करें"
        >
          ✕ बंद करें
        </button>
        {selected && (
          <>
            <img
              src={mediaUrl(selected.data.media)}
              alt={selected.data.title}
            />
            <h2>{selected.data.title}</h2>
            <p>{selected.data.description}</p>
          </>
        )}
      </dialog>
    </>
  );
}
export function FacebookEmbed({ url }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="optional-embed">
      {open ? (
        <>
          <iframe
            src={
              "https://www.facebook.com/plugins/video.php?href=" +
              encodeURIComponent(url) +
              "&show_text=false&width=500"
            }
            title="Facebook video player"
            loading="lazy"
            allow="autoplay; encrypted-media; picture-in-picture"
            allowFullScreen
            referrerPolicy="strict-origin-when-cross-origin"
          />
          <p>Player न चले तो ऊपर Facebook button से मूल वीडियो खोलें।</p>
          <button onClick={() => setOpen(false)}>Player बंद करें</button>
        </>
      ) : (
        <button onClick={() => setOpen(true)}>इस पेज पर player खोलें</button>
      )}
    </div>
  );
}
