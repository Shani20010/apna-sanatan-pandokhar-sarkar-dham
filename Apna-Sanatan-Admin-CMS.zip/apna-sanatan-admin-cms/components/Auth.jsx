"use client";
import { useState } from "react";
import { browserClient } from "../lib/supabase-browser";
export default function Auth({ reset = false }) {
  const [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false);
  async function run(action) {
    setBusy(true);
    setMessage("");
    try {
      const db = browserClient();
      if (!db) throw Error("पहले Supabase setup पूरा करें।");
      let result;
      if (action === "resetmail") {
        result = await db.auth.resetPasswordForEmail(email, {
          redirectTo: location.origin + "/auth/callback?next=/reset-password",
        });
        if (!result.error)
          setMessage(
            "यदि यह email registered है तो reset link भेज दिया गया है। Inbox/Spam देखें।",
          );
      } else if (reset) {
        result = await db.auth.updateUser({ password });
        if (!result.error) {
          await db.auth.signOut();
          location.assign("/login?reset=done");
        }
      } else {
        result = await db.auth.signInWithPassword({ email, password });
        if (!result.error) {
          const role = await db.rpc("is_admin");
          if (role.error || !role.data) {
            await db.auth.signOut();
            throw Error("इस account को admin access नहीं दिया गया है।");
          }
          location.assign("/admin");
        }
      }
      if (result?.error) throw result.error;
    } catch (e) {
      setMessage(e.message || "कोशिश सफल नहीं हुई।");
    } finally {
      setBusy(false);
    }
  }
  return (
    <main className="auth-box">
      <a href="/">← अपना सनातन</a>
      <h1>{reset ? "नया Password" : "Admin Login"}</h1>
      <p>
        {reset
          ? "कम-से-कम 12 अक्षर का नया password रखें।"
          : "केवल अधिकृत व्यवस्थापक के लिए।"}
      </p>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          run("login");
        }}
      >
        {!reset && (
          <label>
            Email
            <input
              type="email"
              required
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </label>
        )}
        <label>
          Password
          <input
            type="password"
            required
            minLength={reset ? 12 : 1}
            autoComplete={reset ? "new-password" : "current-password"}
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
        </label>
        <button disabled={busy}>
          {busy ? "कृपया रुकें…" : reset ? "Password बदलें" : "Login करें"}
        </button>
      </form>
      {!reset && (
        <button disabled={busy || !email} onClick={() => run("resetmail")}>
          Password भूल गए?
        </button>
      )}
      <p role="status">{message}</p>
    </main>
  );
}
