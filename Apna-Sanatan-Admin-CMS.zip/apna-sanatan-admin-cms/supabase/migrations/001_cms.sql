-- Run once in the owner's Supabase SQL Editor. No passwords/keys in this file.
create table public.site_admins (user_id uuid primary key references auth.users(id) on delete cascade, created_at timestamptz not null default now());
alter table public.site_admins enable row level security;
create function public.is_admin() returns boolean language sql stable security definer set search_path='' as $$select exists(select 1 from public.site_admins where user_id=(select auth.uid()));$$;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated;
-- Only the database owner may grant/revoke admin membership. Never use user_metadata for roles.
revoke all on public.site_admins from anon, authenticated;
create table public.content_drafts (
 id uuid primary key default gen_random_uuid(),
 kind text not null check(kind in ('photo','video','banner','announcement','hero','page','faq')),
 data jsonb not null check(jsonb_typeof(data)='object' and octet_length(data::text)<100000),
 sort_order integer not null default 0 check(sort_order between 0 and 1000000),
 starts_at timestamptz, ends_at timestamptz,
 revision integer not null default 1,
 updated_at timestamptz not null default now(),
 check(ends_at is null or starts_at is null or ends_at>starts_at)
);
create unique index one_settings_record on public.content_drafts(kind) where kind='page';
create table public.content_public (
 id uuid primary key references public.content_drafts(id) on delete cascade,
 kind text not null,
 data jsonb not null,
 sort_order integer not null,
 starts_at timestamptz, ends_at timestamptz,
 revision integer not null,
 updated_at timestamptz not null default now()
);
create index public_content_order on public.content_public(kind,sort_order);
create table public.content_audit (id bigint generated always as identity primary key,content_id uuid,action text not null,actor uuid,created_at timestamptz not null default now());
alter table public.content_drafts enable row level security;
alter table public.content_public enable row level security;
alter table public.content_audit enable row level security;
create policy drafts_admin on public.content_drafts for all to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
create policy public_visible on public.content_public for select to anon,authenticated using ((starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>now()));
create policy public_admin on public.content_public for all to authenticated using ((select public.is_admin())) with check ((select public.is_admin()));
create policy audit_admin on public.content_audit for select to authenticated using ((select public.is_admin()));
grant select,insert,update,delete on public.content_drafts,public.content_public to authenticated;
grant select on public.content_public to anon;
grant select on public.content_audit to authenticated;
revoke all on public.content_drafts,public.content_audit from anon;
create function public.audit_content() returns trigger language plpgsql security definer set search_path='' as $$begin
 insert into public.content_audit(content_id,action,actor) values(coalesce(new.id,old.id),TG_TABLE_NAME||':'||TG_OP,auth.uid());return coalesce(new,old);end;$$;
create trigger audit_draft after insert or update or delete on public.content_drafts for each row execute function public.audit_content();
create trigger audit_public after insert or update or delete on public.content_public for each row execute function public.audit_content();
create function public.save_content(p_id uuid,p_kind text,p_data jsonb,p_sort integer,p_starts timestamptz,p_ends timestamptz,p_revision integer)
returns public.content_drafts language plpgsql security invoker set search_path='' as $$declare result public.content_drafts;begin
 if not public.is_admin() then raise insufficient_privilege;end if;
 if p_id is null then
  insert into public.content_drafts(kind,data,sort_order,starts_at,ends_at) values(p_kind,p_data,p_sort,p_starts,p_ends) returning * into result;
 else
  update public.content_drafts set data=p_data,sort_order=p_sort,starts_at=p_starts,ends_at=p_ends,revision=revision+1,updated_at=now() where id=p_id and kind=p_kind and revision=p_revision returning * into result;
  if result.id is null then raise exception 'Content changed' using errcode='40001';end if;
 end if;return result;end;$$;
create function public.publish_content(p_id uuid,p_revision integer) returns void language plpgsql security invoker set search_path='' as $$declare d public.content_drafts;begin
 if not public.is_admin() then raise insufficient_privilege;end if;
 select * into d from public.content_drafts where id=p_id for update;
 if d.id is null or d.revision<>p_revision then raise exception 'Content changed' using errcode='40001';end if;
 insert into public.content_public(id,kind,data,sort_order,starts_at,ends_at,revision,updated_at) values(d.id,d.kind,d.data,d.sort_order,d.starts_at,d.ends_at,d.revision,now())
 on conflict(id) do update set kind=excluded.kind,data=excluded.data,sort_order=excluded.sort_order,starts_at=excluded.starts_at,ends_at=excluded.ends_at,revision=excluded.revision,updated_at=excluded.updated_at;
end;$$;
create function public.remove_content(p_id uuid,p_revision integer,p_delete boolean) returns void language plpgsql security invoker set search_path='' as $$declare d public.content_drafts;begin
 if not public.is_admin() then raise insufficient_privilege;end if;
 select * into d from public.content_drafts where id=p_id for update;
 if d.id is null or d.revision<>p_revision then raise exception 'Content changed' using errcode='40001';end if;
 if d.kind='page' then raise exception 'Website settings cannot be removed';end if;
 delete from public.content_public where id=p_id;
 if p_delete then delete from public.content_drafts where id=p_id;end if;
end;$$;
revoke all on function public.save_content(uuid,text,jsonb,integer,timestamptz,timestamptz,integer),public.publish_content(uuid,integer),public.remove_content(uuid,integer,boolean) from public;
grant execute on function public.save_content(uuid,text,jsonb,integer,timestamptz,timestamptz,integer),public.publish_content(uuid,integer),public.remove_content(uuid,integer,boolean) to authenticated;
-- PRIVATE bucket. Uploaded draft images cannot be read by anonymous visitors.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('site-media','site-media',false,26214400,array['image/jpeg','image/png','image/webp','video/mp4']) on conflict(id) do nothing;
create function public.is_published_media(object_name text) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.content_public p where (p.starts_at is null or p.starts_at<=now()) and (p.ends_at is null or p.ends_at>now()) and object_name in (p.data->>'media',p.data->>'thumbnail',p.data->>'about_image',p.data->>'og_image'));
$$;
revoke all on function public.is_published_media(text) from public;
grant execute on function public.is_published_media(text) to anon,authenticated;
create policy media_public_read on storage.objects for select to anon,authenticated using(bucket_id='site-media' and public.is_published_media(name));
create policy media_admin_read on storage.objects for select to authenticated using(bucket_id='site-media' and (select public.is_admin()));
create policy media_admin_insert on storage.objects for insert to authenticated with check(bucket_id='site-media' and (select public.is_admin()) and name ~ '^uploads/[a-zA-Z0-9_.-]+$');
-- Files are immutable. Replacement uploads get new names. Referenced objects cannot be removed.
create function public.media_in_use(object_name text) returns boolean language sql stable security definer set search_path='' as $$
 select exists(select 1 from public.content_drafts d where object_name in (d.data->>'media',d.data->>'thumbnail',d.data->>'about_image',d.data->>'og_image')) or exists(select 1 from public.content_public p where object_name in (p.data->>'media',p.data->>'thumbnail',p.data->>'about_image',p.data->>'og_image'));
$$;
revoke all on function public.media_in_use(text) from public;
grant execute on function public.media_in_use(text) to authenticated;
create policy media_admin_delete on storage.objects for delete to authenticated using(bucket_id='site-media' and (select public.is_admin()) and not public.media_in_use(name));

-- Explicit backup/restore permissions for the built-in server-only service role.
grant all on public.site_admins,public.content_drafts,public.content_public,public.content_audit to service_role;
grant usage,select on sequence public.content_audit_id_seq to service_role;
revoke all on function public.audit_content() from public;
