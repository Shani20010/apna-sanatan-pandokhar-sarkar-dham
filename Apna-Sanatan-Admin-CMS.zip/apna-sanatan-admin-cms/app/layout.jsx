import "./globals.css";
export const metadata = {
  title: "अपना सनातन पण्डोखर सरकार धाम",
  description: "पावन दर्शन और सनातन संस्कृति",
};
export default function RootLayout({ children }) {
  return (
    <html lang="hi">
      <body>{children}</body>
    </html>
  );
}
