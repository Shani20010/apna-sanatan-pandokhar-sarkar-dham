export default function sitemap() {
  const base = process.env.NEXT_PUBLIC_SITE_URL;
  return base
    ? ["", "/gallery", "/videos"].map((p) => ({
        url: base.replace(/\/$/, "") + p,
        changeFrequency: "weekly",
        priority: p ? 0.7 : 1,
      }))
    : [];
}
