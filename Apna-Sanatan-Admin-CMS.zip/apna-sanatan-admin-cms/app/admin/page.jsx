import { redirect } from "next/navigation";
import { authorized, configured } from "../../lib/supabase-server";
import Admin from "../../components/Admin";
export const dynamic = "force-dynamic";
export const metadata = {
  title: "Admin | अपना सनातन",
  robots: { index: false, follow: false },
};
export default async function Page() {
  if (!configured())
    return (
      <main className="auth-box">
        <h1>Admin setup जरूरी है</h1>
        <p>
          Supabase project बनाकर SQL migration और seed चलाएँ। Netlify में
          .env.example वाले environment variables जोड़ें। पूरी प्रक्रिया
          docs/HINDI-GUIDE.md में है।
        </p>
        <p>
          अभी public website पुराने सुरक्षित content की preview दिखाती है।
          Editing चालू नहीं है।
        </p>
        <a href="/">वेबसाइट देखें</a>
      </main>
    );
  const { user } = await authorized();
  if (!user) redirect("/login");
  return <Admin email={user.email} />;
}
