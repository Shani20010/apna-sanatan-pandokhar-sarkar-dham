import { redirect } from "next/navigation";
import { authorized } from "../../../lib/supabase-server";
import { loadContent } from "../../../lib/content";
import Website from "../../../components/Website";
export const dynamic = "force-dynamic";
export const metadata = {
  title: "Draft Preview",
  robots: { index: false, follow: false },
};
export default async function Preview() {
  if (!(await authorized()).user) redirect("/login");
  return <Website rows={await loadContent(true)} preview />;
}
