"use client";
export default function ErrorPage({ reset }) {
  return (
    <main className="auth-box">
      <h1>पेज अभी लोड नहीं हुआ</h1>
      <p>कनेक्शन या database setup जाँचें। थोड़ी देर बाद फिर कोशिश करें।</p>
      <button onClick={reset}>फिर कोशिश करें</button>
    </main>
  );
}
