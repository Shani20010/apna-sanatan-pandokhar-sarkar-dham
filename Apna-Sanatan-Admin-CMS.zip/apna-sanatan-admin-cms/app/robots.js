export default function robots() {
  return {
    rules: {
      userAgent: "*",
      allow: "/",
      disallow: ["/admin", "/api/admin", "/login", "/reset-password", "/auth"],
    },
    ...(process.env.NEXT_PUBLIC_SITE_URL
      ? {
          sitemap:
            process.env.NEXT_PUBLIC_SITE_URL.replace(/\/$/, "") +
            "/sitemap.xml",
        }
      : {}),
  };
}
