import Auth from "../../components/Auth";
export const metadata = {
  title: "Admin Login",
  robots: { index: false, follow: false },
};
export default function Page() {
  return <Auth />;
}
