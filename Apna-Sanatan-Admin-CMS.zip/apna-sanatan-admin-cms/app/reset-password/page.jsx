import Auth from "../../components/Auth";
export const metadata = {
  title: "Password Reset",
  robots: { index: false, follow: false },
};
export default function Page() {
  return <Auth reset />;
}
