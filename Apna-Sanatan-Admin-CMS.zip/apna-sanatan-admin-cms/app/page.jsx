import Website from "../components/Website";
import { loadContent } from "../lib/content";
import { pageMetadata } from "../lib/metadata";
export const dynamic = "force-dynamic";
export const generateMetadata = () => pageMetadata();
export default async function Page() {
  return <Website rows={await loadContent()} />;
}
