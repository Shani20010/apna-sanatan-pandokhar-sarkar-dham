import { serverClient } from "../../../lib/supabase-server";
export async function GET(request) {
  const url = new URL(request.url),
    code = url.searchParams.get("code");
  const db = await serverClient();
  if (code && db) {
    const { error } = await db.auth.exchangeCodeForSession(code);
    if (!error)
      return Response.redirect(
        new URL(
          url.searchParams.get("next") === "/reset-password"
            ? "/reset-password"
            : "/admin",
          url.origin,
        ),
      );
  }
  return Response.redirect(new URL("/login?error=expired-link", url.origin));
}
