import { guard, failure } from "../../../../lib/admin-request";
import { allRows } from "../../../../lib/queries.mjs";
export async function GET(req) {
  const g = await guard(req);
  if (g.error) return g.error;
  try {
    const [drafts, published] = await Promise.all([
      allRows(g.db, "content_drafts"),
      allRows(g.db, "content_public"),
    ]);
    return Response.json(
      { version: 1, exported_at: new Date().toISOString(), drafts, published },
      {
        headers: {
          "Cache-Control": "private, no-store",
          "Content-Disposition":
            'attachment; filename="sanatan-content-backup.json"',
        },
      },
    );
  } catch (e) {
    return failure(e);
  }
}
