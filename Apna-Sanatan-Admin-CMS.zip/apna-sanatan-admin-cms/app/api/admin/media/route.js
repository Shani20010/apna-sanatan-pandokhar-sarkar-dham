import { allMedia } from "../../../../lib/queries.mjs";
import { guard, failure } from "../../../../lib/admin-request";
export async function GET(req) {
  const g = await guard(req);
  if (g.error) return g.error;
  try {
    return Response.json(
      { files: await allMedia(g.db) },
      { headers: { "Cache-Control": "private, no-store" } },
    );
  } catch (e) {
    return failure(e);
  }
}
export async function DELETE(req) {
  const g = await guard(req, true);
  if (g.error) return g.error;
  const { path } = await req.json();
  if (typeof path !== "string" || !/^uploads\/[a-zA-Z0-9_.-]+$/.test(path))
    return Response.json({ error: "Invalid file" }, { status: 422 });
  const { data: used, error: checkError } = await g.db.rpc("media_in_use", {
    object_name: path,
  });
  if (checkError) return failure(checkError);
  if (used)
    return Response.json(
      {
        error:
          "यह file content में इस्तेमाल हो रही है। पहले उसे replace/remove करें।",
      },
      { status: 409 },
    );
  const { error } = await g.db.storage.from("site-media").remove([path]);
  if (error) return failure(error);
  return Response.json({ ok: true });
}
