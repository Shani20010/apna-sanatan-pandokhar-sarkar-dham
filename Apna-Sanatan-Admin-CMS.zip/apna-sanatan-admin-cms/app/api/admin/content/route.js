import { allRows } from "../../../../lib/queries.mjs";
import { guard, failure } from "../../../../lib/admin-request";
import { recordSchema, schemas } from "../../../../lib/content-schema.mjs";
import { z } from "zod";
export const dynamic = "force-dynamic";
export async function GET(req) {
  const g = await guard(req);
  if (g.error) return g.error;
  try {
    const [drafts, published, audit] = await Promise.all([
      allRows(g.db, "content_drafts"),
      allRows(g.db, "content_public", "id,revision,starts_at,ends_at"),
      g.db
        .from("content_audit")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(12),
    ]);
    if (audit.error) throw audit.error;
    return Response.json(
      {
        drafts: drafts.sort((a, b) => a.sort_order - b.sort_order),
        published,
        audit: audit.data,
      },
      { headers: { "Cache-Control": "private, no-store" } },
    );
  } catch (e) {
    return failure(e);
  }
}
export async function POST(req) {
  const g = await guard(req, true);
  if (g.error) return g.error;
  try {
    if (!req.headers.get("content-type")?.includes("application/json"))
      return Response.json({ error: "JSON required" }, { status: 415 });
    const raw = await req.text();
    if (raw.length > 110000)
      return Response.json({ error: "Content too large" }, { status: 413 });
    const body = JSON.parse(raw);
    if (body.action === "save") {
      const r = recordSchema.parse(body.record);
      const data = schemas[r.kind].parse(r.data);
      const { data: saved, error } = await g.db.rpc("save_content", {
        p_id: r.id ?? null,
        p_kind: r.kind,
        p_data: data,
        p_sort: r.sort_order,
        p_starts: r.starts_at,
        p_ends: r.ends_at,
        p_revision: r.revision,
      });
      if (error) return failure(error);
      return Response.json({ record: saved });
    }
    const a = z
      .object({
        action: z.enum(["publish", "unpublish", "delete"]),
        id: z.string().uuid(),
        revision: z.number().int().min(1),
      })
      .strict()
      .parse(body);
    if (a.action === "publish") {
      const { data: d, error: e } = await g.db
        .from("content_drafts")
        .select("*")
        .eq("id", a.id)
        .single();
      if (e) return failure(e);
      schemas[d.kind].parse(d.data);
    }
    const { error } = await g.db.rpc(
      a.action === "publish" ? "publish_content" : "remove_content",
      a.action === "publish"
        ? { p_id: a.id, p_revision: a.revision }
        : {
            p_id: a.id,
            p_revision: a.revision,
            p_delete: a.action === "delete",
          },
    );
    if (error) return failure(error);
    return Response.json({ ok: true });
  } catch (e) {
    if (e instanceof z.ZodError)
      return Response.json(
        {
          error: e.issues
            .map((x) => x.path.join(".") + ": " + x.message)
            .join("; "),
        },
        { status: 422 },
      );
    return failure(e);
  }
}
