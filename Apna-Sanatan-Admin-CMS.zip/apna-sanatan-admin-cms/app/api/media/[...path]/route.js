import { serverClient, publicClient } from "../../../../lib/supabase-server";
export const dynamic = "force-dynamic";
export async function GET(req, { params }) {
  const { path } = await params;
  const name = path.join("/");
  if (!/^uploads\/[a-zA-Z0-9_.-]+$/.test(name))
    return new Response("Not found", { status: 404 });
  const db = (await serverClient()) || publicClient();
  if (!db) return new Response("Not configured", { status: 503 });
  const { data, error } = await db.storage
    .from("site-media")
    .createSignedUrl(name, 60);
  if (error || !data?.signedUrl)
    return new Response("Not found", { status: 404 });
  return new Response(null, {
    status: 307,
    headers: { Location: data.signedUrl, "Cache-Control": "private, no-store" },
  });
}
