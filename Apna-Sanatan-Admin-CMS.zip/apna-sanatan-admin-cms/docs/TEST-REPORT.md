# Verification report — 25 October 2026 (India)

No production Supabase/Netlify credentials were supplied; no live deployment was made. The previous live website was not changed.

## Performed and passed

- `npm run build`: Next.js production compilation, page generation and route tracing completed. Public content/admin/API routes are dynamic. Full output: `build-output.txt`.
- `npm test`: **18 passing tests**, zero failures, including nested PostgreSQL scenarios. Full output: `test-output.txt`.
- SQL migration and seed executed in **PGlite's actual PostgreSQL engine**, with mocked Supabase-owned auth/storage schemas, roles and auth.uid(). This tests SQL/RLS, not hosted Supabase HTTP services.
- Anonymous published reads; draft read denial; ordinary-user mutation and role-escalation denial.
- Admin draft creation; publish snapshot; draft edits remaining private; revision conflict rejection; future scheduling; unpublish/delete; idempotent seed rerun; audit entries.
- Storage row policies: draft privacy, published visibility, in-use deletion protection, unused deletion and overwrite denial. Actual Storage upload/download requests were not tested.
- Strict validation for unsafe URLs, deceptive Facebook hosts, credential URLs, traversal, invalid schedule intervals, extra fields, invalid verified-view dates/counts and canonical embeds.
- Pagination beyond 1,000 rows. All 34 seed records validate. Twelve photos, eight hero entries and seven distinct Facebook URLs are present.
- Original gallery titles, descriptions, notes, categories, source URLs and paths match original JSON exactly.
- **29 original image/video assets compared using SHA-256: all unchanged.** See `ASSET-PRESERVATION.json`.
- Every bundled seed media reference resolves to an existing file.
- Backup/restore scripts passed Node syntax checks. Credentialed remote operations were not run.
- Browser inspection: homepage, devotional colors, original hero imagery, video cards, native gallery disclosure and admin setup-block screen rendered. Anonymous `/api/admin/content` displayed `Admin login required`.

## Browser verification limit

The managed preview browser blocked `/_next/static/chunks/main-app.js` with `net::ERR_BLOCKED_BY_CLIENT`. Development previews rendered server HTML, but interactive client behavior could not be established. Native gallery disclosure works; lightbox/hero controls were **not verified**. No browser protection was weakened to bypass this environment-specific block.

## Pending owner staging acceptance tests

| Requested test | Current limit |
|---|---|
| Login/logout/password reset | Implementation/build checked; hosted sessions and email delivery untested |
| Unauthorized access | SQL/RLS passed and unconfigured API denial observed; hosted multi-user HTTP test pending |
| Photo upload/delete/compression | Code and Storage RLS checked; actual browser upload/compression and bytes pending |
| Gallery/banner/video/announcement editing | Shared SQL lifecycle and validation tested; end-to-end UI workflow pending |
| Visitor updates | Dynamic rendering/build verified; cross-device production check pending |
| Mobile responsiveness | Responsive styles and touch targets implemented; physical Android/iPhone/tablet tests not performed |
| Performance | Lazy media, compressed uploads and deferred embeds implemented; no Lighthouse/Core Web Vitals score claimed |
| Media loading | References/checksums verified and hero image seen; hosted media/playback pending |
| Netlify compatibility | Dynamic `.next` build/config prepared; Netlify adapter/function deployment not run |
| Production configuration | Templates/instructions supplied; owner accounts not configured |
| Backup/restore | Syntax/schema/validation checked; hosted recovery rehearsal pending |

Use the Hindi guide's acceptance checklist before switching domains. Delivery is an implementation ready for owner configuration, **not a claim that all production acceptance tests are complete**.
