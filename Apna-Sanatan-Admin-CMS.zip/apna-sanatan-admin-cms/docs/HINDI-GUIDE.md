# अपना सनातन — वेबसाइट चलाने की सरल गाइड

## 1. आपको क्या मिलेगा

यह आपकी पुरानी वेबसाइट का Next.js + Supabase CMS upgrade है। गेरुआ theme, Hindi content, 12 gallery photos, आठ hero slides (पुराने drone/video/photo सहित), Facebook page और सात video links रखे गए हैं। पुरानी live website को बदला नहीं गया है। इस नए version को पहले नए Netlify address पर चलाएँ और जाँचें।

Setup पूरा होने के बाद रोज़मर्रा का काम **Android Chrome → आपकी website/admin** से होगा। फोटो, वीडियो link, banner, headings, contact details और announcements के लिए ChatGPT या AI subscription की जरूरत नहीं होगी। Hosting, database, email delivery और domain अपनी-अपनी services पर निर्भर रहेंगे। एक बार accounts/database/deployment setup के लिए computer या किसी भरोसेमंद तकनीकी व्यक्ति की मदद लेना सुविधाजनक होगा।

## 2. तीन accounts अपने नाम पर बनाएँ

1. [GitHub](https://github.com/) — source code की private repository।
2. [Supabase](https://supabase.com/) — database, admin login और uploaded media।
3. [Netlify](https://www.netlify.com/) — website hosting।

अपने email और recovery phone इस्तेमाल करें। Account passwords अपने password manager में रखें, chat या source code में नहीं। Recovery codes सुरक्षित रखें। किसी developer को अपना ownership account न दें; काम खत्म होने पर उसकी access review करें।

## 3. ZIP और source तैयार करें

ZIP extract करें। `package.json`, `netlify.toml`, `app`, `public`, `supabase` एक ही project root में होंगे। `node_modules`, `.next`, `.env.local` GitHub में upload न करें। `.gitignore` पहले से मौजूद है।

Computer पर Node.js 22 LTS या नया compatible version install करें। Project folder के terminal में:

```sh
npm ci
npm test
```

यह source पूरी तरह downloadable है। GitHub Desktop से “Add local repository” / नया repository बनाकर private GitHub repo में publish कर सकते हैं। शुरुआती commit में सभी source files और `package-lock.json` रखें। ZIP file को repository के अंदर upload करने के बजाय उसका extracted project upload करें।

## 4. Supabase project बनाएँ

Supabase dashboard में New project बनाएँ। Region अपने audience के पास चुनें। Database password सुरक्षित रखें; यह admin website password से अलग है। Project तैयार होने पर SQL Editor खोलें।

1. `supabase/migrations/001_cms.sql` की **पूरी file** copy करके नई SQL query में Run करें। यह tables, admin roles, RLS policies और private `site-media` bucket बनाती है। इसे नए project में एक बार चलाएँ। Existing unrelated database में न चलाएँ।
2. फिर `supabase/seed.sql` की पूरी file Run करें। यह पुराने content के 34 records भरती है। Seed फिर चलाने से पहले से मौजूद content overwrite या unpublished item दुबारा publish नहीं होगा।
3. Table Editor में `content_drafts` और `content_public` देखें: प्रारंभ में दोनों में 34 entries होंगी।
4. Storage में `site-media` bucket देखें। **Public bucket toggle OFF ही रखें।** पुराने bundled assets `public/` source में हैं; नए uploads इस bucket में आएँगे।

Table का छोटा परिचय:

| नाम | काम |
|---|---|
| content_drafts | Save किए हुए drafts; केवल admin |
| content_public | Published version; visitors केवल समयानुसार visible content पढ़ते हैं |
| site_admins | केवल owner द्वारा दिए गए admin अधिकार |
| content_audit | Content changes की activity |

SQL Editor की owner access बहुत शक्तिशाली है; सामान्य editing `/admin` से करें।

## 5. अपना admin login बनाएँ

Supabase → Authentication → Users → Add user / Create user में अपना email और एक मजबूत, अलग password डालें। यदि पूछा जाए तो email confirm करें। अपनी account recovery email तक पहुँच होनी चाहिए। User बनने पर उसका **User UID** copy करें।

SQL Editor में यह query चलाएँ, placeholder की जगह अपना असली User UID रखें:

```sql
insert into public.site_admins(user_id)
values ('YOUR-AUTH-USER-UUID'::uuid)
on conflict do nothing;
```

यह UID है, password नहीं। केवल email/password login बना लेना admin access नहीं देता; `site_admins` membership जरूरी है। किसी और admin को जोड़ना हो तो उसका Auth user बनाकर यही प्रक्रिया दोहराएँ। अधिकार हटाने के लिए owner SQL Editor में:

```sql
delete from public.site_admins where user_id = 'USER-UUID-TO-REMOVE'::uuid;
```

अगली protected request पर उसकी editing रुक जाएगी। अपना अंतिम admin गलती से न हटाएँ। Users को खुद admin बनने की अनुमति नहीं है। Authentication settings में public user signup बंद रखें; website पर signup form दिया ही नहीं गया है।

## 6. Environment variables: केवल तीन public values

Supabase Project Settings / Connect / API Keys से Project URL और **publishable key** लें। UI का नाम समय के साथ थोड़ा बदल सकता है। पुराने project की public `anon` key भी इसी variable में इस्तेमाल हो सकती है। **service_role या secret key यहाँ कभी न डालें।**

| Variable | क्या भरना है |
|---|---|
| NEXT_PUBLIC_SUPABASE_URL | आपके project का `https://...supabase.co` URL |
| NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY | public publishable key, या legacy anon key |
| NEXT_PUBLIC_SITE_URL | आपका अंतिम `https://...netlify.app` address; अंत में slash नहीं |

Public key browser में दिखाई दे सकती है; सुरक्षा RLS policies और login से मिलती है। Service-role key RLS bypass करती है और website को कभी नहीं देनी है।

Local development में `.env.example` की copy `.env.local` बनाएँ और values भरें। बिना setup के website पुराने bundled data का preview दिखाती है; admin setup screen दिखाएगा। इसे production-ready database समझकर न छोड़ें।

## 7. Netlify पर deploy करें

1. GitHub में extracted project push करें।
2. Netlify → Add new site/project → Import existing project → GitHub → अपना repository चुनें।
3. Base directory खाली रखें यदि `package.json` repository root में है। Build command `npm run build`; publish directory `.next`; Node version 22। `netlify.toml` में ये settings दी गई हैं।
4. पहले deploy से Netlify का site address मिलेगा। Site settings में मनचाहा उपलब्ध नाम, जैसे `apna-sanatan-pandokhar-sarkar-dham`, चुन सकते हैं; उपलब्धता की guarantee नहीं है।
5. Netlify environment variables में ऊपर की तीन values जोड़ें। Build **और** Functions/runtime scopes में उपलब्ध रखें। Site URL में सही Netlify HTTPS address भरें।
6. नया deployment / clear cache and deploy करें। Next.js adapter Netlify पर अपने-आप detect होना चाहिए; build log में Next/OpenNext support की पुष्टि करें।
7. `/`, `/gallery`, `/videos`, `/admin` खोलकर जाँचें।

**महत्वपूर्ण:** अब यह static export नहीं है। `output: 'export'`, `out` folder, `next export`, SPA `/* /index.html 200` redirect या साधारण ZIP drag-and-drop deploy न लगाएँ। Login cookies, protected routes और dynamic public content को Next.js runtime चाहिए।

Content publish करने पर redeploy नहीं चाहिए। Source code, dependencies, site URL या public environment values बदलें तो redeploy करें।

## 8. Password reset और email delivery

Supabase Authentication → URL Configuration:

- Site URL: आपका exact HTTPS website address।
- Allowed Redirect URL: `https://YOUR-SITE.netlify.app/auth/callback` और यदि exact query matching चाहिए तो `https://YOUR-SITE.netlify.app/auth/callback?next=/reset-password` भी जोड़ें।
- Local testing के लिए अलग localhost callback URL जोड़ सकते हैं; broad wildcard production में न रखें।

Authentication email settings में अपना reliable SMTP provider configure करें। Supabase का default testing email sender production delivery के लिए पर्याप्त न हो सकता है; recipient restrictions और rate limits dashboard/docs से जाँचें। Sender domain का verification भी provider के अनुसार करें।

Reset प्रक्रिया: `/login` खोलें → email भरें → “Password भूल गए?” → email link **उसी phone/Chrome browser** में खोलें जिसमें reset माँगा था (PKCE flow) → नया कम-से-कम 12 अक्षर का password → फिर login। Expired link हो तो नया माँगें। Spam folder भी देखें।

## 9. Android phone से रोज़ का काम

Chrome में आपकी website के आगे `/admin` लगाएँ। Login करें। Chrome menu से “Add to Home screen” shortcut बना सकते हैं। ऊपर tabs horizontally scroll हो सकते हैं। फोन को portrait mode में भी इस्तेमाल कर सकते हैं। हर काम के बाद status message देखें।

### तीन मुख्य buttons

1. **Draft Save:** आपका काम database में सुरक्षित, visitors का पुराना published version अभी वैसा ही।
2. **Preview:** नए tab में **सभी saved drafts** की preview। इसमें unpublished/scheduled drafts भी दिखते हैं; यह live website नहीं है। Unsaved typing preview में नहीं दिखती।
3. **Publish:** visitors के लिए नया version जारी। Schedule रखा है तो उसके समय पर दिखाई देगा। Website नए tab/incognito में refresh करके जाँचें।

सिर्फ Save करके tab बंद करना content publish नहीं करता। दो admins एक item बदल रहे हों तो पुरानी revision को overwrite करने के बजाय reload का संदेश मिलेगा। अपने बदलाव copy करके reload करें।

### नई फोटो / photo replace / category

Gallery tab → नया जोड़ें → Hindi title/description, वैकल्पिक English text, category → Media के नीचे file chooser से phone की gallery चुनें। JPG, PNG, WebP स्वीकार हैं। फोटो अधिकतम 2048 pixels के लंबे किनारे तक resize और WebP compress होती है। मूल phone photo अपने पास रखें; website compression मूल file को phone से नहीं हटाती।

मौजूदा item Edit करके नया Media upload करें तो पुराना thumbnail साफ कर दिया जाता है ताकि नई तस्वीर card पर दिखे। चाहें तो अलग Thumbnail upload करें। Preview में पूरा आकार खोलकर जाँचें। Category का नाम एक जैसा लिखेंगे तो एक group बनेगा। क्रम field छोटी संख्या पहले: 10, 20, 30…; सबसे ऊपर लाने के लिए 0 या छोटा क्रम रखें और Publish करें।

Unpublish से photo visitors से छिपेगी; draft सुरक्षित रहेगा। Delete से record हटेगा, इसलिए confirmation पढ़ें। पुराने bundled files source में सुरक्षित रहेंगे; उनकी permanent removal के लिए code/source change चाहिए।

### Facebook videos

Facebook Videos → नया जोड़ें → असली share/video URL paste करें → title/description लिखें → Thumbnail में संबंधित banner upload करें। गलत banner match न करें। Homepage पर दिखाने के लिए Featured चुनें; Trending अलग tag है। Sort order से priority तय करें। Save → Preview → Publish।

View count चाहें तो **वास्तव में जाँचने के बाद** संख्या भरें: 10 लाख = 1000000। “मैंने view count जाँचा है” tick करें और जाँच की तारीख भरें। बिना verification count नहीं दिखेगा। Seed में कोई unverified numeric count नहीं दिखाया गया है।

Share links कई बार Facebook iframe में “Video unavailable” दिखाते हैं। इसलिए सुंदर banner और original Facebook button हमेशा दिया गया है। यदि Facebook का public canonical URL जैसे `https://www.facebook.com/PAGE/videos/123456789/` उपलब्ध है और embed अनुमति है, optional embed field में डालें। Visitor click करने पर ही player load होगा। Share short-link को इस field में न डालें। Facebook permission/login/region के कारण embed फिर भी न चले तो original button इस्तेमाल होगा; website Facebook की पाबंदियाँ बदल नहीं सकती।

### Banners और hero

Banners tab से banner image, heading, description, HTTPS button URL/text और क्रम बदलें। Desktop/mobile दोनों पर crop जाँचें; मुख्य text किनारों पर न रखें।

Hero Slideshow tab में पुराने आठ entries मौजूद हैं। नई image या छोटी MP4 clip जोड़ें। Media type सही चुनें। Video के लिए poster thumbnail भी लगाएँ। 25 MB से छोटी file रखें; छोटी clips mobile data बचाती हैं। पुराने entries को हटाना जरूरी नहीं। Hero auto चलता है और visitor pause/next कर सकता है; reduced-motion preference में auto रोका जाता है।

### Announcements

सूचनाएँ → नया जोड़ें → title, विवरण, optional HTTPS link → Save/Publish। Start और End समय आपके phone के local time के अनुसार चुनें। खाली Start = तुरंत; खाली End = हमेशा। Database UTC में सुरक्षित रखती है। नया page request आने पर schedule लागू होगा; पहले से खुला tab refresh करना होगा। अलग cron service नहीं चाहिए।

### Website text, contact और SEO

Website Content → एक settings record Edit करें। Brand name, hero text, About, gallery/video headings, फोन, email, Facebook page, footer और SEO title/description बदलें। Hindi और English दोनों Unicode text चलेंगे। FAQ tab से सवाल-जवाब अलग बदलें। SEO में सटीक description रखें; Google तुरंत नया snippet दिखाए इसकी guarantee नहीं है। Save/Preview/Publish करें। Settings record हटाया या schedule नहीं किया जा सकता।

### Media Library

यह नए uploads की सूची है। Path copy करके किसी दूसरे content में वही file इस्तेमाल कर सकते हैं। Unused uploads Delete कर सकते हैं। जिस file का draft या published content में reference है वह नहीं हटेगी। पहले संबंधित records से reference बदलें/हटाएँ और जरूरत के अनुसार publish करें। Image replace नए नाम से upload होती है; पुरानी तस्वीर चुपचाप overwrite नहीं होती।

## 10. अपने domain पर लगाएँ

Domain अपने नाम/email से खरीदें। Netlify Domain management में custom domain जोड़ें और वही DNS records registrar में लगाएँ जो Netlify दिखाए। HTTPS certificate सक्रिय होने दें। फिर:

1. `NEXT_PUBLIC_SITE_URL` नए HTTPS domain से बदलें और redeploy करें।
2. Supabase Site URL और callback allowlist नए domain के अनुसार बदलें।
3. Login/logout/reset और sitemap (`/sitemap.xml`) फिर जाँचें।
4. Domain auto-renewal और recovery email अपने नियंत्रण में रखें।

पुरानी ChatGPT-hosted site इस project से अपने-आप redirect नहीं होगी। उसे बदलना/बंद करना अलग निर्णय है।

## 11. Backup: तीन चीजें बचाकर रखें

- **Source:** यह ZIP और GitHub repository। पुराने bundled photos/videos इसी में हैं।
- **Database content:** Admin → Backup → Content JSON डाउनलोड। इसमें drafts और published versions हैं, पर media bytes/Auth users नहीं।
- **Uploaded media:** Supabase Storage की files या नीचे full-backup script। Database backup में Storage की असली files स्वतः शामिल मानकर न चलें।

महत्वपूर्ण बदलाव के बाद backup लें। नियमित साप्ताहिक backup अच्छा आरंभ है। दो अलग सुरक्षित स्थानों पर रखें। Drafts निजी हो सकते हैं; backup public repository में न रखें।

### Full content + media backup (computer)

यह काम owner या भरोसेमंद तकनीकी सहायक करे। Service-role key केवल अपने सुरक्षित **local terminal environment** में डालें; Netlify public variables, website source, screenshot या chat में कभी नहीं। Scripts `.env.local` से service-role secret अपने-आप नहीं पढ़ते।

Bash/macOS/Linux में secret को history में लिखे बिना:

```sh
read -r -p 'Supabase URL: ' SUPABASE_URL
export SUPABASE_URL
read -r -s -p 'Service-role key: ' SUPABASE_SERVICE_ROLE_KEY
export SUPABASE_SERVICE_ROLE_KEY
npm run backup -- backups/my-backup-2026-10-24
unset SUPABASE_SERVICE_ROLE_KEY
```

Windows PowerShell में session environment सुरक्षित तरीके से भरें; key command text में paste करके terminal history में न छोड़ें। Tool secret print नहीं करता। `content.json` और `media/` साथ रखें; JSON में media SHA-256 checksums हैं। यह application-content backup है, पूरी PostgreSQL schema/Auth export का replacement नहीं। Schema migration source में है। Supabase dashboard/CLI database backups अलग रखें; official backup docs देखें।

### Restore

1. नया user-owned Supabase project बनाएँ।
2. केवल `001_cms.sql` चलाएँ। **Seed न चलाएँ**, restore target खाली होना चाहिए।
3. Backup का `content.json` और `media/` एक folder में हों। नए project की local backup credentials set करें।
4. चलाएँ:

```sh
npm run restore -- backups/my-backup-2026-10-24 --confirm-empty-project
```

Script nonempty content tables पर रुकती है; overwrite नहीं करती। File checksums पहले जाँचे जाते हैं। Network failure से partial restore हो तो backup सुरक्षित रखें और नया साफ target बनाकर फिर restore करें। यह कई HTTP operations हैं, पूरी restore एक atomic database transaction नहीं है।

5. नए Auth users बनाएँ; `site_admins` access फिर जोड़ें। पुराने passwords export नहीं किए गए हैं। Historical audit JSON में है; नई database audit नए import को दर्ज करेगी।
6. Netlify में नए Supabase URL/public key डालकर redeploy करें; URLs/SMTP/admin reset setup करें। सभी photos और links जाँचें।

अगर केवल Netlify hosting खराब हो लेकिन Supabase ठीक है: GitHub source से दूसरे Next.js-compatible host पर deploy करें, वही Supabase public values रखें, नया Site URL/Auth redirects configure करें। अगर database खो गई: ऊपर full restore करें। अगर केवल JSON बचा और uploaded media नहीं बची तो media पूर्ण रूप से restore नहीं होगी।

## 12. खर्च और free-tier की सीमा

24 October 2026 को उपलब्ध official pricing के अनुसार Supabase Free में 500 MB database और 1 GB file storage जैसे सीमित quotas हैं; egress, Auth/email और inactive-project policy भी लागू हो सकती है। Netlify credit-based Free plan में 300 monthly credits दिखाए गए हैं; deployment, traffic और compute credits इस्तेमाल कर सकते हैं। आपके account की पुरानी/new billing plan अलग हो सकती है।

इसे unlimited या हमेशा zero-cost hosting न समझें। Images compress करें, लंबी videos Facebook पर रखें, unused uploads साफ करें, usage alerts देखें। Content edits में redeploy न होने से unnecessary builds बचते हैं। Domain और production SMTP अलग खर्च हो सकते हैं। Plan/payment चुनने से पहले current dashboard और pricing देखें:

- https://supabase.com/pricing
- https://supabase.com/docs/guides/platform/billing-on-supabase
- https://www.netlify.com/pricing/

## 13. Launch से पहले आपकी acceptance checklist

अपने configured staging Netlify address पर जाँचें:

- Admin login, logout, गलत password और password reset email।
- Incognito में `/admin` editing न मिले; APIs unauthorized हों।
- दूसरी ordinary Auth user को admin न मिले।
- Photo upload/replace, Hindi/English description, category, क्रम, draft preview और publish।
- Draft photo incognito में उपलब्ध न हो; published photo दूसरे phone में दिखे।
- Banner schedule/start/end, announcement hide/delete।
- Facebook link और banner सही मिलें; optional embed असफल होने पर button काम करे।
- Phone Chrome, iPhone Safari, tablet/desktop पर header, photo dialog और admin forms।
- Logout के बाद refresh/back से admin access न मिले।
- Backup डाउनलोड और एक अलग empty project में restore rehearsal।
- Supabase Security Advisor और Netlify build/function logs में समस्या न हो।

## 14. समस्या आए तो

“Admin setup जरूरी” = public environment values नहीं मिलीं; Netlify में जोड़कर rebuild करें।
“Admin access नहीं” = Auth user का UID `site_admins` में नहीं है।
“Page load नहीं हुआ” = configured Supabase unavailable/SQL missing; provider status और tables देखें। Site पुराने bundled content को चुपचाप वापस publish नहीं करती।
“Invalid origin” = actual site URL और `NEXT_PUBLIC_SITE_URL` अलग हैं या proxy गलत है; exact HTTPS origin ठीक करें।
“Content बदल चुका है” = दूसरा edit हुआ है; text सुरक्षित copy करके page reload करें।
Upload fail = type/25 MB सीमा/session/storage quota/policies जाँचें। iPhone HEIC को पहले JPG में बदलें।
Password reset fail = SMTP, redirect allowlist, same browser और link expiry जाँचें।

तकनीकी reference:

- https://supabase.com/docs/guides/auth/server-side/creating-a-client
- https://supabase.com/docs/guides/database/postgres/row-level-security
- https://supabase.com/docs/guides/storage/security/access-control
- https://supabase.com/docs/guides/platform/backups
- https://docs.netlify.com/build/frameworks/framework-setup-guides/nextjs/overview/
