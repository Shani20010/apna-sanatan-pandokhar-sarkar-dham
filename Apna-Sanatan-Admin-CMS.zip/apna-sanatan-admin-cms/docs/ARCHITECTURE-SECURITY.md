# Architecture and security notes

## Migration decision

The supplied ZIP was a static-export Next.js App Router site with `public/photos.json`, bundled images/media and a browser script. Browser-local video entries were not shared between visitors. Its original files are retained in `legacy-source/` for reference; the old script is not served or executed. All media in the supplied ZIP is retained byte-for-byte. Five requested popular Facebook links and their available matching banners are also included.

The upgrade removes `output: export`. Request-time server components read Supabase published content using the PUBLIC publishable key without user credentials. Netlify's Next.js runtime hosts server rendering, protected APIs and authentication callback. No runtime ChatGPT, Work, AI or Sites integration exists. This repository does not modify the previous live site.

## Access model

- `site_admins`: owner-only membership. No user metadata authorization, public signup UI or self-enrollment.
- `auth.getUser()` validates authenticated requests; `is_admin()` verifies allowlist membership again. Proxy refreshes Supabase cookies, never substitutes for authorization.
- Every admin mutation requires authenticated administrator, matching Origin and validated JSON. API authorization remains necessary even if someone loads client code directly.
- Supabase RLS is the final access boundary. Anonymous visitors have SELECT on currently scheduled `content_public` rows only; no draft access. Ordinary authenticated users have no content-writing policy.
- Draft and public versions are physically separate tables. Draft save cannot accidentally update visible content. Transactional publication locks the row and checks its revision. Stale saves/publishes/deletes fail with SQLSTATE 40001.
- Page settings are a singleton; normal admin UI/API cannot delete, unpublish or schedule them.
- Audit triggers record actor, record ID and operation. Full historic content versions are not stored in the audit table; use backups for restoration.
- Public key is intentionally browser-visible. No service-role key or password is present in source. A server secret is not necessary for normal website runtime.

## Media model

`site-media` is PRIVATE. Authenticated admins can upload new immutable object names, read drafts and delete unused objects. There is no UPDATE policy; replacement uploads cannot alter already-published images. Anonymous storage reads require an exact reference from a visible published row. `/api/media/uploads/...` generates a 60-second signed redirect under the caller's RLS, with private/no-store headers.

Unpublishing hides new requests; a previously issued signed URL can work for up to 60 seconds. Downloaded files cannot be recalled. Original `/public` assets were already publicly served and remain public even when their content record is hidden. This is a devotional content CMS, not a confidential document repository.

Image uploads are limited to JPEG/PNG/WebP, resize to max 2048 px and WebP quality 0.86 in the browser; original HEIC is not accepted. MP4 hero uploads are capped at 25 MiB. Browser input checks and bucket MIME/size policy are both used. Images/video are served on Supabase's separate origin, not executed as HTML. No SVG/HTML uploads or arbitrary external image URLs are supported. Trusted admins are not a substitute for a malware-scanning pipeline; no enterprise antivirus scanning is included.

Deletion is blocked when a file is referenced by any draft/published record. An admin can still create a reference to a missing path by manual entry, so preview before publishing. Cross-service upload and SQL content changes cannot form one atomic transaction; interrupted uploads may leave harmless unreferenced files, removable from Media Library.

## Scheduling and freshness

RLS compares start/end timestamps against database time. No cron or paid scheduler is needed. New requests reflect new content immediately without redeployment. A visitor who already has a page open must refresh to see subsequent changes. Preview shows all saved drafts, regardless of published state or schedule. Content reads paginate beyond Supabase's default response cap, then sort deterministically; larger sites should add public pagination/search endpoints instead of loading their entire catalog.

## Facebook

Share links use stable direct-link cards, not unreliable automatically embedded short URLs. Optional canonical `/videos/<id>` or `video.php?v=<id>` URLs can enable a click-to-load Facebook iframe. An external button is always available. Facebook owns login, region, deletion and embedding restrictions. No automatic metadata scraping or invented view counts. Verified counts require a positive number and date entered by an admin.

## Deployment and hardening

- Node 22+, locked dependencies, `npm ci`, `next build --webpack`, dynamic `.next` deployment on Netlify.
- Owner configures exact Supabase redirect allowlist, production SMTP, provider rate limits and signup restrictions; use HTTPS.
- Security headers include nosniff, frame same-origin and restrictive device permissions. No blanket CSP is supplied because nonce-based Next streaming plus optional Facebook/Google Fonts requires deployment-specific validation; evaluate a report-only CSP before enforcing.
- Do not cache `/admin`, `/api/admin`, authentication responses or signed media redirects at an external CDN. Do not add a global SPA rewrite.
- Keep dashboard accounts protected by provider MFA and recovery codes. Application TOTP MFA UI is not implemented; required scope is email/password plus allowlist.
- Public API inputs use strict Zod schemas and React text rendering, not arbitrary HTML. HTTPS link validation blocks scripts and credentials; Facebook domains are exact/suffix checked.
- Monitor Supabase Auth logs, application audit, provider quotas and security updates. This work is not an external penetration-test certification.

## Backup limitations

`backup.mjs` exports all content/audit rows and uploaded media with checksums. Source ZIP retains original assets. It does not export Auth password hashes, provider settings or domain ownership. `restore.mjs` requires a fresh migrated empty project; it verifies media and schemas before writes. It is not transactionally atomic across Storage/PostgREST. If interrupted, restore into another clean target. Recreate Auth users/admin membership and email/domain settings manually. Audit history remains in the backup; new restore operations create fresh audit rows.
