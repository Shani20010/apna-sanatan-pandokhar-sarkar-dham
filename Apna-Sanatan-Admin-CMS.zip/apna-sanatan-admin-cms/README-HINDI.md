# पहले यह पढ़ें

पूरा नया setup और Android management guide: [docs/HINDI-GUIDE.md](docs/HINDI-GUIDE.md)

यह dynamic Next.js + Supabase project है। पुराने static-export instructions लागू नहीं हैं। Netlify पर GitHub से deploy करें, `out` folder से नहीं।
