# अपना सनातन पण्डोखर सरकार धाम — Next.js

दो pages वाला पूरा Next.js App Router project। मूल गेरुआ design, Hindi fonts, 12 photo entries, original gallery assets, clickable details, hero photo slideshow और 16-second photo-based video montage शामिल हैं। Contact: 9752514002 / pandokhardham684@gmail.com. Facebook: https://www.facebook.com/share/1CMTTMbwFh/

## सबसे आसान Netlify deployment

ZIP extract करें। अंदर `out` folder पहले से build करके दिया है। Netlify में manual deploy / drag-and-drop से **सिर्फ out folder** upload करें। Source project की ZIP को direct static site की तरह upload न करें। `out/index.html` उस folder के अंदर सीधे होना चाहिए।

## GitHub से automatic deployment (भविष्य में editing के लिए)

1. पूरे project के source files GitHub repository में upload करें। `node_modules`, `.next` और `out` Git में डालना जरूरी नहीं है।
2. Netlify में अपने Git provider से repository import करें।
3. Base directory: project root (जहाँ package.json है)।
4. Build command: `npm run build`
5. Publish directory: `out`
6. Node version: 22. `netlify.toml` में settings मौजूद हैं।
7. Deploy करें। भविष्य में Git push से नया build deploy होगा।

## अपने computer पर चलाना

Node.js 22 या नया version install करें। Project folder के terminal में:

```sh
npm ci
npm run dev
```

http://localhost:3000 खोलें। Production files फिर बनाने के लिए:

```sh
npm run build
```

Next.js static export से `out` बनता है। इसके लिए `next export` या `next start` की जरूरत नहीं है।

## अपना domain बाद में जोड़ना

Domain खरीदने/अपने नाम पर होने के बाद Netlify project में Domain management → Add a domain → Add a domain you already own चुनें। अपना domain डालें। Netlify के Pending DNS verification में दिए गए **आपके domain के exact records** अपने registrar/DNS provider पर जोड़ें, या Netlify DNS के निर्देश मानें। DNS verify होने और HTTPS certificate बनने के बाद primary domain सेट करें। पुराने email MX/TXT records सुरक्षित रखें। Domain केवल code में लिख देने से register या connect नहीं होता।

## Content कहाँ edit करना है

- `app/page.jsx`: homepage, contact, Facebook link, headings, FAQs.
- `app/gallery/page.jsx`: gallery page और footer.
- `app/layout.jsx`: browser title और meta description.
- `app/globals.css`: gerua colours, fonts, responsive design, animation.
- `public/photos.json`: सभी photo titles, Hindi details, reference links, category और image paths.
- `public/images`: original gallery photos और previews.
- `public/media/darshan-montage.mp4`: photographs से बना silent animated video (live footage नहीं).
- `public/site.js`: filters, modal, slideshow और browser-local video link controls. Next Script इसे hydration के बाद load करता है। Internal anchors full page navigation रखते हैं ताकि DOM interactions साफ तरीके से initialize हों।

## Video links का व्यवहार

Facebook page link स्थायी है। “वीडियो जोड़ें” से जोड़े links केवल उसी browser/domain के localStorage में रहते हैं, सभी visitors को नहीं दिखते। पुराने ChatGPT Site domain के browser-saved links Netlify/custom domain में transfer नहीं होते। सभी visitors को fixed videos दिखाने के लिए homepage में permanent Facebook links जोड़ें और दोबारा build करें। इसमें admin login, database या video upload backend नहीं है।

## आधिकारिक documentation

- https://nextjs.org/docs/app/guides/static-exports
- https://docs.netlify.com/build/frameworks/framework-setup-guides/nextjs/overview/
- https://docs.netlify.com/manage/domains/manage-domains/assign-a-domain-to-your-site-app/
- https://docs.netlify.com/manage/domains/configure-domains/configure-external-dns/

Source export तैयार करने की तारीख: 23 October 2026. आपकी मौजूदा live website में कोई बदलाव नहीं किया गया।

## Drone hero update
Hero playlist में तीन 5.5-second drone clips (720p, silent, warm colour grade और soft fades) जोड़ी गई हैं। पुराना 16-second photo-video और चारों photos सुरक्षित हैं। क्रम public/site.js की playlist में बदल सकते हैं। Drone source upload को edit नहीं किया गया है।

## Facebook video page
अलग वीडियो पेज: /videos/. नया link/banner जोड़ने के लिए app/videos/page.jsx में नया article जोड़ें और image public/images में रखें। Banner व button दोनों में एक ही Facebook URL रखें।

## Unified homepage update
Home, पूरी gallery और Facebook videos अब homepage पर scroll करके दिखते हैं। नए video/banner app/page.jsx के videos section में जोड़ें। Legacy /gallery/ और /videos/ URLs उपलब्ध हैं, पर मुख्य menu homepage sections पर जाता है।
